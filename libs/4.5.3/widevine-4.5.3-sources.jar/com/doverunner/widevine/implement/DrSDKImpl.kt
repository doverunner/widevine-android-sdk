package com.doverunner.widevine.implement

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.Util
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceInputStream
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.StatsDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.drm.ExoMediaDrm
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.smoothstreaming.SsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.CmcdConfiguration
import com.doverunner.widevine.db.DBManager
import com.doverunner.widevine.drm.WvLicenseManager
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.model.DownloadState
import com.doverunner.widevine.model.WvCallback
import com.doverunner.widevine.model.DrmInformation
import com.doverunner.widevine.model.WvEventListener
import com.doverunner.widevine.model.FileInformation
import com.doverunner.widevine.sdk.DrWvSDK
import com.doverunner.widevine.track.DownloaderTracks
import com.doverunner.widevine.util.Constants.DR_CUSTOM_DATA_HEADER
import com.doverunner.widevine.util.DownloadManagerUtil
import com.doverunner.widevine.util.GlobalObjectUtil
import com.doverunner.widevine.util.OneTime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import androidx.core.net.toUri
import androidx.media3.common.Player
import com.doverunner.widevine.BuildConfig
import com.doverunner.widevine.cmcd.CmcdManager

data class MediaSourceInfo(val factory: MediaSource.Factory, val mimeType: String)

/** @suppress */
class DrWvSDKImpl : DrWvSDK {
    private var context: Context
    private var contentData: ContentData

    //    private var pallyConEventListener: PallyConEventListener? = null
    private var downloadManager: com.doverunner.widevine.downloader.DownloadManager
    private var wvLicenseManager: WvLicenseManager
    private var keySetId: ByteArray? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var contentFactory: HttpDataSource.Factory
//        override fun createCmcdConfiguration(mediaItem: MediaItem): CmcdConfiguration {
//            if (cmcdConfiguration != null) return cmcdConfiguration!!
//            CmcdConfiguration.Factory.DEFAULT
//            return createCmcdConfiguration(mediaItem)

//            val cmcdRequestConfig = object : CmcdConfiguration.RequestConfig {
//                override fun isKeyAllowed(key: String): Boolean {
////                        return key == "br" || key == "bl"
//                    return true
//                }
//
//                override fun getCustomData(): ImmutableMap<String, String> {
//                    return ImmutableMap.of(
//                        CmcdConfiguration.KEY_CMCD_OBJECT, "test=abcd"
//                    )
//                }
//
//                override fun getRequestedMaximumThroughputKbps(throughputKbps: Int): Int {
//                    return 5 * throughputKbps
//                }
//            }
//
//            val sessionId = UUID.randomUUID().toString()
//            val contentId = UUID.randomUUID().toString()
//
//
//            return CmcdConfiguration(sessionId, contentId, cmcdRequestConfig)
//        }
//    }

    override fun release() {
        updateSecureTime()
        downloadManager.release()
        DownloadManagerUtil.release()
        GlobalObjectUtil.release()
    }

    override fun downloadLicense(
        format: Format?,
        onSuccess: (() -> Unit),
        onFailed: ((WvException) -> Unit),
    ) {
        val success: ((ByteArray) -> Unit) = { id ->
            scope.launch {
                keySetId = id
                downloadManager.setLicenseData(id)
                onSuccess.invoke()
            }
        }

        val failed: ((WvException) -> Unit) = { exception ->
            scope.launch {
                onFailed.invoke(exception)
            }
        }

        if (format != null) {
            this.downloadLicenseForFormat(format, success, failed)
        } else {
            this.downloadLicenseInter(success, failed)
        }
    }

    override fun renewLicense() {
        val keySetId = this.keySetId ?: downloadManager.getDownloadRequest()?.keySetId
        ?: throw WvException.DrmException(null, "not downloaded license")
        this.keySetId = wvLicenseManager.renewDrmLicense(keySetId)
    }

    override fun removeLicense() {
        val keySetId = this.keySetId ?: downloadManager.getDownloadRequest()?.keySetId
        ?: throw WvException.DrmException(null, "not downloaded license")
        wvLicenseManager.removeDrmLicense(keySetId)
    }

    override fun download(downloaderTracks: DownloaderTracks) {
//        val callback = licenseFailureCallback ?: { _: Exception -> false }
        DownloadManagerUtil.getInstance().startDownloadService(context)
        if (downloaderTracks.video.isEmpty() && downloaderTracks.audio.isEmpty()) {
            throw WvException.DownloadException(null, "downloaderTracks is empty")
        }

        val localKeySetId = keySetId ?: downloadManager.getDownloadRequest()?.keySetId
        if (localKeySetId == null) {
            this.downloadLicenseInter({ id ->
                downloadManager.startDownload(downloaderTracks, id)
            }, { e ->
                when(e) {
                    is WvException.ClearKeyLicenseException -> {
                        CoroutineScope(Dispatchers.Default).launch {
                            downloadManager.startDownload(downloaderTracks, null)
                        }
                    }
                    else -> {
                        CoroutineScope(Dispatchers.Main).launch {
                            GlobalObjectUtil.getInstance().notifyFailed(contentData, e)
                        }
                    }
                }

//                if (callback?.invoke(e) == true) {
//                    CoroutineScope(Dispatchers.Default).launch {
//                        downloadManager.startDownload(downloaderTracks, null)
//                    }
//                }
//                downloadManager.startDownload(downloaderTracks, null)
            })
        } else {
            val state = getDownloadState()
            if (state == DownloadState.REMOVING || state != DownloadState.COMPLETED) {
                downloadManager.startDownload(downloaderTracks, localKeySetId)
            }
//            if (state == DownloadState.REMOVING) {
//                CoroutineScope(Dispatchers.Default).launch {
//                    downloadManager.startDownload(downloaderTracks, localKeySetId)
////                    downloadManager.resumeAllDownload()
//                }
//            } else if (state != DownloadState.COMPLETED) {
//                CoroutineScope(Dispatchers.Default).launch {
//                    downloadManager.startDownload(downloaderTracks, localKeySetId)
//                }
//            }
        }
    }

    override fun pauseAll() {
        downloadManager.pauseAllDownload()
    }

    override fun resumeAll() {
        downloadManager.resumeAllDownload()
    }

    override fun stop() {
        downloadManager.stop()
    }

    override fun remove() {
//        downloadManager.stopDownload()
        if (contentData.url == null) {
            throw WvException.ContentDataException(null, "content url is nothing")
        }

        var migratedContent = ""
        var removeKey = ""

        contentData.contentId?.let { contentId ->
            migratedContent =
                DBManager.getInstance(context).getOldContentLocalUrl(contentId)
            if (migratedContent.isNotEmpty()) {
                removeKey = contentId
            }
        } ?: run {
            val url =
                contentData.url ?: throw IllegalArgumentException("Content URL must not be null")
            migratedContent = DBManager.getInstance(context).getOldContentLocalUrl(url)
            removeKey = url
        }

//        if (contentData.contentId != null) {
//            migratedContent =
//                PallyConDBManager.getInstance(context).getOldContentLocalUrl(contentData.contentId!!)
//            if (migratedContent.isNotEmpty()) {
//                removeKey = contentData.contentId!!
//            }
//        } else {
//            migratedContent =
//                PallyConDBManager.getInstance(context).getOldContentLocalUrl(contentData.url!!)
//            removeKey = contentData.url!!
//        }

        try {
            if (migratedContent.isNotEmpty()) {
                deleteOldContent(migratedContent)
                DBManager.getInstance(context).removeOldContentLocalUrl(removeKey)
            }

            downloadManager.removeDownload()
        } catch (e: IOException) {
            throw WvException.DownloadException(e, "download contents is nothing")
        } catch (e: Exception) {
            throw WvException.DownloadException(e, "download contents is nothing")
        }
    }

    override fun removeAll() {
        val list = DBManager.getInstance(context).getOldAllContentLocalUrls()
        for (localPath in list) {
            deleteOldContent(localPath)
        }
        DBManager.getInstance(context).removeAllOldContents()
        downloadManager.removeAllDownload()
    }

    override fun updateSecure(
        onSuccess: (() -> Unit),
        onFailed: ((WvException) -> Unit),
    ) {
        updateSecureTime(onSuccess = onSuccess, onError = onFailed)
    }

    @Deprecated(
        message = "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.addWvListener(wvEventListener)"),
        level = DeprecationLevel.WARNING
    )
    override fun setPallyConEventListener(wvEventListener: WvEventListener?) {
        GlobalObjectUtil.getInstance().setListener(wvEventListener)
    }

    @Deprecated(
        message = "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.addWvListener(wvEventListener)"),
        level = DeprecationLevel.WARNING
    )
    override fun setPallyConCallback(wvCallback: WvCallback?, dummy: Unit?) {
        GlobalObjectUtil.getInstance().setCallback(wvCallback)
    }

    override fun getContentTrackInfo(
        onSuccess: ((DownloaderTracks) -> Unit),
        onFailed: ((WvException) -> Unit),
    ) {
        val drmSessionManager = wvLicenseManager.getDrmSession()
        downloadManager.prepare(drmSessionManager, { _ ->
            downloadManager.getTracks()?.let {
                onSuccess.invoke(it)
            }
        }, { exception ->
            wvLicenseManager.reCreateDrmSession()
            onFailed.invoke(exception)
        })
    }

    override fun getDrmInformation(): DrmInformation {
        val keySetId = this.keySetId ?: downloadManager.getDownloadRequest()?.keySetId
        ?: return DrmInformation(0, 0)

        return wvLicenseManager.getDrmInformation(keySetId)
    }

    override fun getDownloadFileInformation(): FileInformation {
        return downloadManager.getDownloadFileInformation()
    }

    override fun getMediaSource(): MediaSource {
        CmcdManager.getInstance().setContentId(contentData.contentId ?: contentData.url ?: "")
        CmcdManager.getInstance().setAuthData(
            contentData.drmConfig?.token ?: contentData.drmConfig?.customData ?: "")
        return getMediaSource(wvLicenseManager.getDrmSession())
    }

    override fun getMediaSource(drmSessionManager: DrmSessionManager): MediaSource {
        if (contentData.url == null) {
            WvException.ContentDataException(null, "content url is nothing")
        }

        val downloadRequest = downloadManager.getDownloadRequest()
        val keySetId = this.keySetId ?: downloadRequest?.keySetId

//        var migratedContent = ""
//        if (contentData.contentId != null) {
//            migratedContent =
//                PallyConDBManager.getInstance(context).getOldContentLocalUrl(contentData.contentId!!)
//        }
//
//        if (migratedContent.isEmpty()) {
//            migratedContent =
//                PallyConDBManager.getInstance(context).getOldContentLocalUrl(contentData.url!!)
//        }

        val migratedContent = contentData.contentId?.let { contentId ->
            DBManager.getInstance(context).getOldContentLocalUrl(contentId)
        } ?: contentData.url?.let { url ->
            DBManager.getInstance(context).getOldContentLocalUrl(url)
        } ?: ""

        // secure time
        updateSecureTime(null) { e ->
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, e)
            }
        }

        if (DBManager.isModified) {
            throw WvException.DetectedDeviceTimeModifiedException(
                null,
                "Modified device time. A network connection is required."
            )
        }

        val downloadState = this.getDownloadState()

        return when {
            migratedContent.isNotEmpty() -> createMediaSourceFromLocalFile(
                MediaItem.fromUri(migratedContent),
                keySetId,
                DefaultDataSource.Factory(context)
            )

            (downloadState == DownloadState.COMPLETED || downloadState == DownloadState.DOWNLOADING) &&
                    downloadRequest != null &&
                    contentData.contentId!! == downloadRequest.id ->
                createMediaSourceFromLocalFile(
                    downloadRequest.toMediaItem(),
                    keySetId,
                    getDataSourceFactory()
                )

            downloadState == DownloadState.COMPLETED &&
                    keySetId != null -> createMediaSourceFromLocalFile(
                MediaItem.fromUri(contentData.url!!),
                keySetId,
                DefaultDataSource.Factory(context)
            )

            else -> createMediaSourceFromRemoteUrl(
                contentData.url!!,
                keySetId,
                drmSessionManager
            )
        }
    }

    private fun removeAllLicense() {
        downloadManager.getAllDownloadKeySetIds().let {
            for (keySetId in it) {
                try {
                    wvLicenseManager.removeDrmLicense(keySetId)
                } catch (e: WvException) {
                    continue
                }
            }
        }
    }

    private fun createMediaSourceFromLocalFile(
        mediaItem: MediaItem,
        keySetId: ByteArray?,
        dataSourceFactory: DataSource.Factory,
    ): MediaSource {
        if (mediaItem.localConfiguration == null) {
            throw WvException.ContentDataException(
                null,
                "mediaItem is wrong. localConfiguration is null"
            )
        }

        val builder = mediaItem.buildUpon()
        keySetId?.let {
            builder.setDrmConfiguration(
                MediaItem.DrmConfiguration.Builder(contentData.drmConfig!!.uuid)
                    .setKeySetId(keySetId).build()
            )
        }

//        val item = mediaItem.buildUpon()
//            .setDrmConfiguration(
//                MediaItem.DrmConfiguration.Builder(contentData.drmConfig!!.uuid)
//                    .setKeySetId(keySetId).build()
//            )

        return createMediaSource(mediaItem.localConfiguration!!.uri, dataSourceFactory, builder)
    }

    private fun buildRequestHeaders(): Map<String, String> {
        val requestHeaders = mutableMapOf<String, String>()

        // 쿠키 추가
        contentData.cookie?.let {
            requestHeaders["Cookie"] = it
        }

        // HTTP 헤더 추가
        contentData.httpHeaders?.forEach { entry ->
            if (entry.key != null && entry.value != null) {
                requestHeaders[entry.key!!] = entry.value!!
            }
        }

        // DRM 관련 헤더 추가
        contentData.drmConfig?.token?.let {
            requestHeaders[DR_CUSTOM_DATA_HEADER] = it
        }

        contentData.drmConfig?.customData?.let {
            requestHeaders[DR_CUSTOM_DATA_HEADER] = it
        }

        return requestHeaders
    }

    private fun createMediaSourceFromRemoteUrl(
        url: String,
        keySetId: ByteArray?,
        drmSessionManager: DrmSessionManager,
    ): MediaSource {
        val drmConfigBuilder = MediaItem.DrmConfiguration.Builder(contentData.drmConfig!!.uuid)
            .setMultiSession(true)

        val mediaItemBuilder = MediaItem.fromUri(url).buildUpon().setUri(url)

        if (keySetId != null) {
            // KeySetId가 있는 경우 간단히 설정
            drmConfigBuilder.setKeySetId(keySetId)
        } else {
            // 요청 헤더 설정
            val requestHeaders = buildRequestHeaders()

            // DRM 라이센스 URL과 헤더 설정
            drmConfigBuilder.setLicenseUri(contentData.drmConfig!!.drmLicenseUrl)
                .setLicenseRequestHeaders(requestHeaders)
        }

        // MediaItem에 DRM 설정 적용
        mediaItemBuilder.setDrmConfiguration(drmConfigBuilder.build())

        // MediaSource 생성 및 반환
        return if (keySetId != null) {
            createMediaSource(url.toUri(), contentFactory, mediaItemBuilder)
        } else {
            createMediaSource(url.toUri(), contentFactory, mediaItemBuilder, drmSessionManager)
        }
    }

    override fun getMediaItem(): MediaItem {
        val mediaSource = getMediaSource()
        return mediaSource.mediaItem
    }

    override fun getDataSourceFactory(): DataSource.Factory {
        if (contentData.url == null) {
            throw WvException.ContentDataException(
                null,
                "content url is nothing"
            )
        }

        if (contentData.drmConfig == null) {
            throw WvException.ContentDataException(
                null,
                "don't set drmConfig"
            )
        }

        val okHttpClient = OkHttpClient.Builder()
//            .addInterceptor(CustomInterceptor())
            .build()

        val okHttpDataSourceFactory = OkHttpDataSource.Factory(okHttpClient)

        val downloadRequest = downloadManager.getDownloadRequest()
        return if (downloadRequest == null) {
            DefaultDataSource.Factory(context, okHttpDataSourceFactory)
//            DefaultDataSource.Factory(context)
        } else {
            val util = DownloadManagerUtil.getInstance()
            val cacheDataSourceFactory = CacheDataSource.Factory()
                .setCache(util.getCache(context))
                .setUpstreamDataSourceFactory(util.getHttpDataSource())
                .setCacheWriteDataSinkFactory(null)

            cacheDataSourceFactory
        }
    }

    override fun getDownloadState(): DownloadState {
        return downloadManager.getDownloadState()
    }

    override fun getDrmSessionManager(): DrmSessionManager {
        return wvLicenseManager.getDrmSession()
    }

    override fun getKeySetId(): ByteArray? {
        val downloadRequest = downloadManager.getDownloadRequest()
        return this.keySetId ?: downloadRequest?.keySetId
    }

    override fun needsMigrateDownloadedContent(): Boolean {
        if (contentData.url == null) {
            throw WvException.ContentDataException(
                null,
                "content url is null"
            )
        }

        if (contentData.contentId == null) {
            throw WvException.ContentDataException(
                null,
                "contentId is null"
            )
        }

        if (contentData.drmConfig == null) {
            throw WvException.ContentDataException(
                null,
                "drmConfig is null"
            )
        }

        val needsMigrateForChangeUrlToKey =
            DBManager.getInstance(context).getOldContentLocalUrl(contentData.url!!)

        return needsMigrateForChangeUrlToKey.isNotEmpty()
    }

    override fun migrateDownloadedContent(
        contentName: String,
        downloadedFolderName: String?,
    ): Boolean {
        if (contentData.url == null) {
            throw WvException.ContentDataException(
                null,
                "content url is null"
            )
        }

        if (contentData.contentId == null) {
            throw WvException.ContentDataException(
                null,
                "contentId is null"
            )
        }

        if (contentData.drmConfig == null) {
            throw WvException.ContentDataException(
                null,
                "drmConfig is null"
            )
        }

        val needsMigrateForChangeUrlToKey =
            DBManager.getInstance(context).getOldContentLocalUrl(contentData.url!!)

        var isSuccess = false

        if (needsMigrateForChangeUrlToKey.isNotEmpty()) {
            DBManager.getInstance(context).changeUrlToKey(
                contentData.url!!,
                contentData.contentId!!
            )
            isSuccess = true
        }

        return isSuccess
    }

    override fun reProvisionRequest(
        onSuccess: (() -> Unit),
        onFailed: ((WvException) -> Unit),
    ) {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val frameworkMediaDrm = FrameworkMediaDrm.newInstance(C.WIDEVINE_UUID)
                val exoMediaDrmProvider = ExoMediaDrm.AppManagedProvider(frameworkMediaDrm)
                val exoMediaDrm = exoMediaDrmProvider.acquireExoMediaDrm(C.WIDEVINE_UUID)
                val currentProvisionRequest = exoMediaDrm.provisionRequest
                val requestURL = (currentProvisionRequest.defaultUrl + "&signedRequest="
                        + Util.fromUtf8Bytes(currentProvisionRequest.data))
                val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                    .setUserAgent(Util.getUserAgent(context, "PallyConWVSDK"))
                val dataSource = StatsDataSource(httpDataSourceFactory.createDataSource())
                var manualRedirectCount = 0
                var dataSpec = DataSpec.Builder()
                    .setUri(requestURL)
                    .setHttpMethod(DataSpec.HTTP_METHOD_POST)
                    .setFlags(DataSpec.FLAG_ALLOW_GZIP)
                    .build()

                while (true) {
                    val inputStream = DataSourceInputStream(dataSource, dataSpec)
                    try {
//                        val byteResponse = Util.toByteArray(inputStream)
                        val byteResponse = inputStream.readBytes()
                        exoMediaDrm.provideProvisionResponse(byteResponse)
                        removeAllLicense()
                        CoroutineScope(Dispatchers.Main).launch {
                            onSuccess()
                        }
                        return@launch
                    } catch (e: HttpDataSource.InvalidResponseCodeException) {
                        val redirectUrl: String = getRedirectUrl(e, manualRedirectCount) ?: throw e
                        manualRedirectCount++
                        dataSpec = dataSpec.buildUpon().setUri(redirectUrl).build()
                    } finally {
                        Util.closeQuietly(inputStream)
                    }
                }
            } catch (e: WvException) {
                CoroutineScope(Dispatchers.Main).launch {
                    onFailed.invoke(e)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                CoroutineScope(Dispatchers.Main).launch {
                    onFailed.invoke(
                        WvException.DrmException(e, e.message ?: "failed reProvisionRequest")
                    )
                }
            }
        }
    }

    @Deprecated(
        "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.setDownloadService(DownloadService)"),
        level = DeprecationLevel.WARNING
    )
    override fun setDownloadService(service: Class<out DownloadService?>?, dummy: Unit?) {
        DownloadManagerUtil.getInstance().setService(service)
    }

    @Deprecated(
        "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.getDownloadManager(Context)"),
        level = DeprecationLevel.WARNING
    )
    override fun getDownloadManager(context: Context, dummy: Unit?): DownloadManager {
        return DownloadManagerUtil.getInstance().getDownloadManager(context)
    }

    private fun downloadLicenseInter(
        onSuccess: ((ByteArray) -> Unit)?,
        onError: ((WvException) -> Unit)?,
    ) {
        val drmSessionManager = wvLicenseManager.getDrmSession()
        downloadManager.prepare(drmSessionManager, { _ ->
            downloadManager.getFirstFormatWithDrmInitData({
                wvLicenseManager.downloadLicense(it, { keySetId ->
                    onSuccess?.invoke(keySetId)
                }, { downloadLicenseException ->
                    onError?.invoke(downloadLicenseException)
                })
            }, { getDrmInitDataException ->
                onError?.invoke(getDrmInitDataException)
            })

        }, { downloadException ->
            onError?.invoke(downloadException)
        })
    }

    override fun setPlayer(player: Player) {
        CmcdManager.getInstance().attach(player)
        CmcdManager.getInstance().setVersion(BuildConfig.VERSION_NAME)
    }

    private fun downloadLicenseForFormat(
        format: Format,
        onSuccess: ((ByteArray) -> Unit)?,
        onError: ((WvException) -> Unit)?,
    ) {
        wvLicenseManager.downloadLicense(format, { keySetId ->
            onSuccess?.invoke(keySetId)
        }, { downloadLicenseException ->
            onError?.invoke(downloadLicenseException)
        })
    }

    private fun updateSecureTime(
        onSuccess: (() -> Unit)? = null,
        onError: ((WvException) -> Unit)? = null,
    ) {
        DBManager.getInstance(context).updateSecureTime(onSuccess) {
            onError?.invoke(
                WvException.DetectedDeviceTimeModifiedException(
                    null,
                    "Modified device time. " +
                            "A network connection is required."
                )
            )
        }
    }

    private fun deleteOldContent(localUrl: String) {
        val filePath = localUrl.substring(0, localUrl.lastIndexOf('/'))
        val file = File(filePath)
        file.deleteRecursively()
    }

    private fun createMediaSource(
        uri: Uri,
        dataSourceFactory: DataSource.Factory,
        builder: MediaItem.Builder,
        drmSessionManager: DrmSessionManager? = null,
    ): MediaSource {
        val (factory, mediaItem) = when (Util.inferContentType(uri)) {
            C.CONTENT_TYPE_DASH -> MediaSourceInfo(
                DashMediaSource.Factory(dataSourceFactory),
                MimeTypes.APPLICATION_MPD
            )

            C.CONTENT_TYPE_HLS -> MediaSourceInfo(
                HlsMediaSource.Factory(dataSourceFactory),
                MimeTypes.APPLICATION_M3U8
            )

            C.CONTENT_TYPE_SS -> MediaSourceInfo(
                SsMediaSource.Factory(dataSourceFactory),
                MimeTypes.APPLICATION_SS
            )

            C.CONTENT_TYPE_OTHER -> MediaSourceInfo(
                ProgressiveMediaSource.Factory(dataSourceFactory),
                MimeTypes.APPLICATION_MP4
            )

            else -> throw WvException.ContentDataException(null, "Type is not supported")
        }.let { (factory, mimeType) ->
            factory.apply {
                drmSessionManager?.let { drm ->
                    setDrmSessionManagerProvider { _ -> drm }
                }
                GlobalObjectUtil.getInstance().cmcdConfigurationFactory?.let {
                    setCmcdConfigurationFactory(it)
                }
            } to builder.setMimeType(mimeType).build()
        }

        return factory.createMediaSource(mediaItem)
    }

    constructor(
        context: Context,
        contentData: ContentData,
    ) {
        OneTime.getInstance(context)

        this.context = context
        this.contentData = contentData


        val okHttpClient = OkHttpClient.Builder()
//            .addInterceptor(CustomInterceptor())
            .build()

//        val okHttpDataSourceFactory = OkHttpDataSource.Factory(okHttpClient)

//        contentFactory = OkHttpDataSource.Factory(OkHttpClient.Builder().build())
//        val licenseFactory = OkHttpDataSource.Factory(OkHttpClient.Builder().build())
        contentFactory = OkHttpDataSource.Factory(okHttpClient)
        val licenseFactory = OkHttpDataSource.Factory(okHttpClient)

        val contentRequestProperties = HashMap<String, String>()
        contentData.cookie?.let {
            contentRequestProperties["Cookie"] = it
        }

        contentData.httpHeaders?.let {
            for (entry in it) {
                if (entry.key != null && entry.value != null) {
                    contentRequestProperties[entry.key!!] = entry.value!!
                }
            }
        }

        contentFactory.setDefaultRequestProperties(contentRequestProperties)

        val licenseRequestProperties = HashMap<String, String>()
        contentData.drmConfig?.cookie?.let {
            licenseRequestProperties["Cookie"] = it
        }

        contentData.drmConfig?.httpHeaders?.let {
            for (entry in it) {
                if (entry.key != null && entry.value != null) {
                    licenseRequestProperties[entry.key!!] = entry.value!!
                }
            }
        }

        licenseFactory.setDefaultRequestProperties(licenseRequestProperties)

        this.wvLicenseManager =
            WvLicenseManager(context, contentData, licenseFactory)

        this.downloadManager =
            com.doverunner.widevine.downloader.DownloadManager(context, contentData, contentFactory)

        updateSecureTime()
    }

    companion object {
        fun createWvSDK(
            context: Context,
            contentData: ContentData,
        ): DrWvSDK {
            CmcdManager.getInstance().createObject(context)
            return DrWvSDKImpl(context, contentData)
        }

        fun setDownloadDirectory(
            context: Context,
            directoryName: String,
        ) {
            DownloadManagerUtil.getInstance().setDownloadDirectory(context, directoryName)
        }

        fun setWvCallback(wvCallback: WvCallback?) {
            GlobalObjectUtil.getInstance().setCallback(wvCallback)
        }

        fun setDownloadService(service: Class<out DownloadService?>?) {
            DownloadManagerUtil.getInstance().setService(service)
        }

        fun addWvEventListener(wvEventListener: WvEventListener) {
            GlobalObjectUtil.getInstance().addListener(wvEventListener)
        }

        fun removeWvEventListener(wvEventListener: WvEventListener) {
            GlobalObjectUtil.getInstance().removeListener(wvEventListener)
        }

        fun getDownloadManager(context: Context): DownloadManager {
            return DownloadManagerUtil.getInstance().getDownloadManager(context)
        }

        fun setCmcdConfigurationFactory(factory: CmcdConfiguration.Factory?) {
            GlobalObjectUtil.getInstance().cmcdConfigurationFactory = factory
        }

        private fun getRedirectUrl(
            exception: HttpDataSource.InvalidResponseCodeException, manualRedirectCount: Int,
        ): String? {
            // For POST requests, the underlying network stack will not normally follow 307 or 308
            // redirects automatically. Do so manually here.
            val manuallyRedirect = ((exception.responseCode == 307 || exception.responseCode == 308)
                    && manualRedirectCount < 5)
            if (!manuallyRedirect) {
                return null
            }
            val headerFields = exception.headerFields
            val locationHeaders = headerFields["Location"]
            if (!locationHeaders.isNullOrEmpty()) {
                return locationHeaders[0]
            }
            return null
        }
    }
}