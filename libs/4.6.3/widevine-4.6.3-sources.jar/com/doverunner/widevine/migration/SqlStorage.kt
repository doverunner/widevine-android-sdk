package com.doverunner.widevine.migration

internal object SqlStorage {
    const val CREATE_SQL_CONTENT_TABLE = "CREATE TABLE IF NOT EXISTS Content (" +
            "contentIndex INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "keySetId TEXT NOT NULL, " +
            "cid TEXT NOT NULL, " +
            "playbackDuration TEXT NOT NULL, " +
            "licenseDuration TEXT NOT NULL, " +
            "registeredDate Date NOT NULL, " +
            "siteId TEXT NOT NULL, " +
            "offlineLicenseExpireDate TEXT NOT NULL" +
            ");"
    const val CREATE_SQL_TIME_TABLE = "CREATE TABLE IF NOT EXISTS Time (" +
            "owner TEXT NOT NULL, " +
            "tickTime TEXT NOT NULL, " +
            "tickCount INTEGER NOT NULL " +
            ");"
    const val CREATE_SQL_AUTH_TABLE = "CREATE TABLE IF NOT EXISTS Auth (" +
            "siteId TEXT, " +
            "sdkCode TEXT " +
            ");"
    const val ALTER_SQL_CONTENT_TABLE_ADD_SITEID = "ALTER TABLE Content ADD " +
            "siteId TEXT NOT NULL DEFAULT ''" +
            ";"
    const val ALTER_SQL_CONTENT_TABLE_ADD_COLUMN_EXPIREDATE = "ALTER TABLE Content ADD COLUMN " +
            "offlineLicenseExpireDate TEXT DEFAULT 0"
    const val SELECT_SQL_CONTENT = "SELECT * FROM 'Content' %s ORDER BY contentIndex"
    const val SELECT_SQL_CONTENT_LIMIT = "SELECT * FROM 'Content' LIMIT 0"
    const val SELECT_SQL_AUTH = "SELECT * FROM 'Auth'"
    const val SELECT_SQL_TIME = "SELECT * FROM 'Time'"
    const val DELETE_SQL_CONTENT = "DELETE FROM 'Content' %s;"
    const val DELETE_SQL_TIME = "DELETE FROM 'Time' %s;"
    const val DELETE_SQL_AUTH = "DELETE FROM 'Auth';"
}
