package com.doverunner.widevine.migration

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

internal class DataBaseHelper(
    context: Context?,
    name: String?,
    factory: SQLiteDatabase.CursorFactory?,
    version: Int
) :
    SQLiteOpenHelper(context, name, factory, version) {

    @Throws(SQLiteException::class)
    override fun onCreate(sqLiteDatabase: SQLiteDatabase) {
        sqLiteDatabase.execSQL(SqlStorage.CREATE_SQL_CONTENT_TABLE)
        sqLiteDatabase.execSQL(SqlStorage.CREATE_SQL_TIME_TABLE)
        sqLiteDatabase.execSQL(SqlStorage.CREATE_SQL_AUTH_TABLE)
    }

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.d(TAG, "onUpgrade.")
        if (oldVersion < 2) {
            sqLiteDatabase.execSQL(SqlStorage.ALTER_SQL_CONTENT_TABLE_ADD_SITEID)
        }
        if (oldVersion < 3) {
            sqLiteDatabase.execSQL(SqlStorage.CREATE_SQL_AUTH_TABLE)
        }
    }

    override fun onDowngrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        Log.d(TAG, "onDowngrade.")
    }

    companion object {
        private const val TAG = "pallycon_database"
    }
}
