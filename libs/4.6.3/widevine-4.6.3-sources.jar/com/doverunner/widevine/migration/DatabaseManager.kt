package com.doverunner.widevine.migration

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.util.Log
import com.doverunner.widevine.exception.WvException

internal class DatabaseManager(private val context: Context) {
    private var dataBaseHelper: DataBaseHelper? = null
    private var readableDatabase: SQLiteDatabase? = null
    private var writableDatabase: SQLiteDatabase? = null
    private var isInit = false
    fun close() {
        dataBaseHelper?.close()
    }

    private fun getReadableDatabase() {
        readableDatabase = dataBaseHelper?.getReadableDatabase()
    }

    private fun getWritableDatabase() {
        writableDatabase = dataBaseHelper?.getWritableDatabase()
    }

    fun getAllContent(): ArrayList<RecordContent> {
        val contents = ArrayList<RecordContent>()
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return contents
        }
        val sql: String = java.lang.String.format(SqlStorage.SELECT_SQL_CONTENT)
        val cursor = rawQuery(sql)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    setContentUsingCursor(cursor, 0)?.let {
                        contents.add(it)
                    }
                } while (cursor.moveToNext())
            }
            cursor.close()
        }
        return contents
    }

    fun getContent(cid: String, siteId: String): RecordContent? {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return null
        }
        val sql: String = java.lang.String.format(
            SqlStorage.SELECT_SQL_CONTENT,
            "WHERE cid='$cid' AND siteId='$siteId'"
        )
        var content: RecordContent? = null
        val cursor = rawQuery(sql)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    content = setContentUsingCursor(cursor, 0)
                } while (cursor.moveToNext())
            }
            cursor.close()
        }
        return content
    }

    val time: RecordTime?
        get() {
            if (!isInit) {
                Log.d(TAG, "DatabaseManager have not been initialized.")
                return null
            }
            val sql = String.format(SqlStorage.SELECT_SQL_TIME)
            var time: RecordTime? = null
            val cursor = rawQuery(sql)
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    do {
                        time = setTimeUsingCursor(cursor, 0)
                    } while (cursor.moveToNext())
                }
                cursor.close()
            }
            return time
        }

    @Throws(SQLiteException::class)
    fun deleteContent(cid: String, siteId: String): Boolean {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return false
        }
        val sql: String = java.lang.String.format(
            SqlStorage.DELETE_SQL_CONTENT,
            "WHERE cid='$cid' AND siteId='$siteId'"
        )
        //Log.d(TAG, "execSQL : " + sql);
        return execSQL(sql)
    }

    fun deleteAllContent(siteId: String) {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return
        }
        var sql = if (siteId.isEmpty()) {
            String.format("DELETE FROM 'Content'")
        } else {
            java.lang.String.format(SqlStorage.DELETE_SQL_CONTENT, "WHERE siteId='$siteId'")
        }
        //Log.d(TAG, "execSQL : " + sql);
        execSQL(sql)
    }

    fun deleteTime(owner: String) {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return
        }
        val sql: String = java.lang.String.format(
            SqlStorage.DELETE_SQL_TIME,
            "WHERE owner='$owner'"
        )
        //Log.d(TAG, "execSQL : " + sql);
        execSQL(sql)
    }

    fun deleteAuth() {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return
        }
        val sql: String = java.lang.String.format(SqlStorage.DELETE_SQL_AUTH, "")
        //Log.d(TAG, "execSQL : " + sql);
        execSQL(sql)
    }

    private fun rawQuery(sql: String): Cursor? {
        if (!isInit) {
            Log.d(
                TAG,
                "DatabaseManager have not been initialized."
            )
            return null
        }
        if (readableDatabase == null || readableDatabase!!.isOpen == false) {
            getWritableDatabase()
        }
        //Log.d(TAG, "rawQuery : " + sql);
        return readableDatabase!!.rawQuery(sql, null)
    }

    @Throws(SQLiteException::class)
    private fun execSQL(sql: String): Boolean {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return false
        }
        if (writableDatabase == null || writableDatabase!!.isOpen == false) {
            getWritableDatabase()
        }
        writableDatabase!!.execSQL(sql)
        return true
    }

    private fun setContentUsingCursor(cursor: Cursor, columnIdx: Int): RecordContent? {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return null
        }
        val content = RecordContent()
        var columnIndex = columnIdx
        content.contentIndex = cursor.getInt(columnIndex++)
//        val encKeySetId = cursor.getString(columnIndex++)

        try {
            content.keySetId = ""
            if (content.getKeySetId().isEmpty()) {
                content.keySetId = cursor.getString(columnIndex-1)
            }
        } catch (e: WvException.MigrationException) {
            e.printStackTrace()
            return null
        } catch (e: IllegalArgumentException) {
            content.keySetId = cursor.getString(columnIndex-1)
        }

        content.cid = cursor.getString(columnIndex++)
        content.playbackDuration = cursor.getString(columnIndex++)
        content.licenseDuration = cursor.getString(columnIndex++)
        content.registeredDate = cursor.getString(columnIndex++)
        content.siteId = cursor.getString(columnIndex)
        return content
    }

    private fun setTimeUsingCursor(cursor: Cursor, columnIdx: Int): RecordTime? {
        if (!isInit) {
            Log.d(TAG, "DatabaseManager have not been initialized.")
            return null
        }
        val time = RecordTime()
        var columnIndex = columnIdx
        var tickTime = ""
        time.owner = cursor.getString(columnIndex++)
//        val encTickTime = cursor.getString(columnIndex++)
        try {
            // Naver TS, Jul. 31, 2018
            // 'java.lang.IllegalArgumentException: bad base-64' at decrypt();
            tickTime = ""

            // 'java.lang.NumberFormatException: For input string' at parseLong();
            time.tickTime = tickTime.toLong()
            Log.d(TAG, "parseLong is success.")

            // decrypt() 함수 자체는 성공했으나, 반환된 문자열에 문제가 있을 경우에만
            // parseLong() 에서 예외가 발생한다.
            // 즉, decrypt() 의 결과가 문제가 없다면 parseLong() 에서도 예외가 발생하지 않아야 한다.
            // decrypt() 에서의 근본적 문제가 해결된다면 parseLong() 역시 문제가 없다.
        } catch (e: WvException.MigrationException) {
            throw WvException.MigrationException(e, "[time] " + e.message)
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e(TAG, "tickTime : $tickTime")
            throw WvException.MigrationException(e, "[time] tickTime:$tickTime")
        }
        //// ============
        time.tickCount = cursor.getLong(columnIndex)
        return time
    }

    companion object {
        private const val TAG = "pallycon_database"
        private const val databaseName = "pallyconDataBase"
        private const val dataBaseVersion = 4
    }

    init {
        try {
            dataBaseHelper = DataBaseHelper(context, databaseName, null, dataBaseVersion)
            readableDatabase = dataBaseHelper?.getReadableDatabase()
            writableDatabase = dataBaseHelper?.getWritableDatabase()

            // Add 'offlineLicenseExpireDate' column if it doesn't exist.
            val cur = readableDatabase!!.rawQuery(SqlStorage.SELECT_SQL_CONTENT_LIMIT, null)
            if (cur.getColumnIndex("offlineLicenseExpireDate") == -1) {
                writableDatabase!!.execSQL(SqlStorage.ALTER_SQL_CONTENT_TABLE_ADD_COLUMN_EXPIREDATE)
            }
            isInit = true
        } catch (e: Exception) {
            isInit = false
            throw e
        }
    }
}