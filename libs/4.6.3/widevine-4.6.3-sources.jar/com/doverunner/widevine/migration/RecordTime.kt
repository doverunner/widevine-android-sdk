package com.doverunner.widevine.migration

internal class RecordTime {
    var owner = ""
    var tickTime: Long = 0
    var tickCount: Long = 0
}
