package com.doverunner.widevine.migration

import android.util.Base64

internal class RecordContent {
    var contentIndex = -1
    var siteId = ""
    var keySetId = ""
    var cid = ""
    var registeredDate = ""
    var playbackDuration = ""
    var licenseDuration = ""
    var offlineLicenseExpireDate = ""
    fun setKeySetId(bytes: ByteArray?) {
        keySetId = Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun getKeySetId(): ByteArray {
        return Base64.decode(keySetId, Base64.NO_WRAP)
    }

    fun logString(): String {
        return """
            contentIndex : $contentIndex
            siteId : $siteId
            keySetId : $keySetId
            cid : $cid
            playbackDuration : $playbackDuration
            licenseDuration : $licenseDuration
            registeredDate : ${registeredDate}offlineLicenseExpireDate : $offlineLicenseExpireDate
            """.trimIndent()
    }
}