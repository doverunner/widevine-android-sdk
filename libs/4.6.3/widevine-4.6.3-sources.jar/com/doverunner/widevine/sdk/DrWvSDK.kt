package com.doverunner.widevine.sdk;

import android.content.Context
import androidx.annotation.Keep
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.CmcdConfiguration
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.implement.DrWvSDKImpl
import com.doverunner.widevine.model.*
import com.doverunner.widevine.track.DownloaderTracks

/**
 *
 */
interface DrWvSDK {

    /**
     * Releases the [DrWvSDK].
     * IMPORTANT: Called when the created Activity/Context is destroy.
     * The [DrWvSDK] must not be used after calling this method.
     */
    fun release()

    /**
     * Download the license for offline.
     *
     * @param format The [Format] of the content whose license is to be downloaded.
     * If it's null, the format value is taken directly from the content url(remote content) internally to download the license.
     * @param onSuccess Called when license download is successful
     * @param onFailed [WvException.DrmException] if do not have a downloaded license
     * [WvException.DownloadException] If the content file does not exist or cannot be removed
     */
    fun downloadLicense(format: Format?, onSuccess: (() -> Unit), onFailed: ((WvException) -> Unit))

    /**
     * Renew offline licenses already downloaded.
     *
     * @Throws [WvException.DrmException] if do not have a downloaded license
     */
    @Throws(WvException.DrmException::class)
    fun renewLicense()

    /**
     * Remove offline licenses already downloaded
     *
     * @Throws [WvException.LicenseNotFoundException] if there is no license to remove — it was
     * never downloaded or has already been removed. A retried removal can treat this as
     * already completed.
     * @Throws [WvException.DrmException] if the removal fails on the device.
     */
    @Throws(WvException.LicenseNotFoundException::class, WvException.DrmException::class)
    fun removeLicense()

    /**
     * Remove offline licenses already downloaded, without blocking the calling thread.
     *
     * The local license keys are invalidated immediately; notifying the license server is
     * best-effort and kept within a few seconds even on a poor network. Callbacks are
     * delivered on the main thread. All errors are reported through [onFailed]; nothing is
     * thrown to the caller.
     *
     * @param onSuccess Called when the license removal is finished.
     * @param onFailed [WvException.LicenseNotFoundException] if there is no license to remove
     * (never downloaded or already removed — a retried removal can treat this as success),
     * or [WvException.DrmException] if the removal fails on the device.
     */
    fun removeLicense(onSuccess: (() -> Unit), onFailed: ((WvException) -> Unit))

    /**
     * Starts the service if not started already and adds a new download.
     * If an error occurs during DRM license download, [WvEventListener.onFailed] will be called.
     *
     * @param downloaderTracks The tracks to be downloaded, including video and audio data.
     *
     * @Throws [WvException.ContentDataException] if contentData is wrong
     * @throws [WvException.DownloadException] If the content file does not exist or cannot be accessed
     */

    @Throws(
        WvException.ContentDataException::class,
        WvException.DownloadException::class
    )
    fun download(downloaderTracks: DownloaderTracks)

    /**
     * Pauses all downloading content.
     */
    fun pauseAll()

    /**
     * Starts the service if not started already and resumes all downloads.
     */
    fun resumeAll()

    /**
     * Stop downloading content.
     *
     * It can be called at any time after [download], including while the offline license is still
     * being acquired and the download has not started yet. In that case the download is never
     * started and [WvEventListener.onStopped] is called.
     */
    fun stop()

    /**
     * Remove the content already downloaded.
     *
     * Removal is best effort: a content file that cannot be deleted does not stop the download
     * record from being cleaned up, and the failure is reported once everything else is removed.
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DownloadException] If the content cannot be removed. Check
     * [WvException.DownloadException.reason] to tell the cases apart:
     * [WvException.DownloadErrorReason.NOT_FOUND] when there is no downloaded content to remove
     * (it may already have been removed), and
     * [WvException.DownloadErrorReason.REMOVE_FAILED] when the content exists but deleting it
     * failed, for example because of a permission or I/O error. NOT_FOUND can usually be treated
     * as success; REMOVE_FAILED is worth retrying or surfacing to the user.
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DownloadException::class
    )
    fun remove()

    /**
     * Remove all the content that was downloaded.
     *
     * Cleanup is best effort: a content that cannot be deleted does not stop the others from
     * being removed. It does not fail when there is nothing to remove, so it is safe to call
     * unconditionally.
     *
     * @throws [WvException.DownloadException] with
     * [WvException.DownloadErrorReason.REMOVE_FAILED] if any content exists but could not be
     * deleted. The message lists the contents that failed.
     */
    @Throws(
        WvException.DownloadException::class
    )
    fun removeAll()

    /**
     * Called for playback when [WvException.DetectedDeviceTimeModifiedException],
     * which is a device time manipulation error, occurs.
     * The device must be connected to a network.
     *
     * @param onSuccess Called when license download is successful
     * @param onFailed [WvException.DetectedDeviceTimeModifiedException]
     */
    fun updateSecure(onSuccess: (() -> Unit), onFailed: ((WvException) -> Unit))

    /**
     * Set a [WvEventListener]
     *
     * @param wvEventListener The listener to be added.
     */
    @Deprecated(
        message = "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.addWvListener(wvEventListener)"),
        level = DeprecationLevel.WARNING
    )
    fun setPallyConEventListener(wvEventListener: WvEventListener?)

    /**
     * Set a [WvCallback]
     *
     * @param wvCallback The callback to be added.
     */
    @Deprecated(
        message = "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.setWvCallback(wvCallback)"),
        level = DeprecationLevel.WARNING
    )
    fun setPallyConCallback(wvCallback: WvCallback?, dummy: Unit? = null)

    /**
     * Sets the user's DownloadService associated with download notifications.
     *
     * @param service the [DownloadService] class user created.
     */
    @Deprecated(
        message = "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.setDownloadService(DownloadService)"),
        level = DeprecationLevel.WARNING
    )
    fun setDownloadService(service: Class<out DownloadService?>?, dummy: Unit? = null)

    /**
     * Get a [DownloaderTracks]
     * The device must be connected to a network.
     *
     * When contentData is wrong, the [WvEventListener.onFailed] listener is called.
     * failed prepare in SDK, the [WvEventListener.onFailed] listener is called.
     *
     * @param onSuccess Called when license download is successful
     * @param onFailed [WvException.DownloadException] if do not have a downloaded content,
     * [WvException.NetworkConnectedException] if do not connected network
     * [WvException.ContentDataException] if the contentData is wrong
     */
    fun getContentTrackInfo(
        onSuccess: ((DownloaderTracks) -> Unit),
        onFailed: ((WvException) -> Unit)
    )

    /**
     * Get a [DrmInformation]
     *
     * @throws [WvException.DrmException] if the DRM information is not retrieved. It also happens when you don't have a license.
     *
     * @return [DrmInformation]
     */
    fun getDrmInformation(): DrmInformation

    /**
     * Get a [FileInformation]
     *
     * @return content file information [FileInformation]
     */
    fun getDownloadFileInformation(): FileInformation

    /**
     * Get a [MediaSource].
     * Play content via pass to ExoPlayer.
     * @see <a href="https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/source/MediaSource.html">MediaSource</a>
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DetectedDeviceTimeModifiedException] if the device time manipulation error
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DetectedDeviceTimeModifiedException::class
    )
    fun getMediaSource(): MediaSource

    /**
     * Get a [MediaSource].
     * Play content via pass to ExoPlayer.
     * @see <a href="https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/source/MediaSource.html">MediaSource</a>
     *
     * @param options Per-call playback options, see [PlaybackOptions]. The SDK keeps no state for
     * them, so the same SDK instance can hand out an offline MediaSource and a streaming one
     * (e.g. as a fallback when the offline license turned out to be expired) without being
     * released and recreated.
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DetectedDeviceTimeModifiedException] if the device time manipulation error
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DetectedDeviceTimeModifiedException::class
    )
    fun getMediaSource(options: PlaybackOptions): MediaSource

    /**
     * Get a [MediaSource](https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/source/MediaSource.html).
     * Play content via pass to ExoPlayer.
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DetectedDeviceTimeModifiedException] if the device time manipulation error
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DetectedDeviceTimeModifiedException::class
    )
    fun getMediaSource(drmSessionManager: DrmSessionManager): MediaSource

    /**
     * Get a [MediaSource](https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/source/MediaSource.html).
     * Play content via pass to ExoPlayer.
     *
     * @param options Per-call playback options, see [PlaybackOptions].
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DetectedDeviceTimeModifiedException] if the device time manipulation error
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DetectedDeviceTimeModifiedException::class
    )
    fun getMediaSource(
        drmSessionManager: DrmSessionManager,
        options: PlaybackOptions,
    ): MediaSource

    /**
     * Get a [MediaItem].
     * Play content via pass to ExoPlayer.
     *
     * @see <a href="https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/MediaItem.html">MediaItem</a>
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DetectedDeviceTimeModifiedException] if the device time manipulation error
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DetectedDeviceTimeModifiedException::class
    )
    fun getMediaItem(): MediaItem

    /**
     * Get a [MediaItem].
     * Play content via pass to ExoPlayer.
     *
     * @see <a href="https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/MediaItem.html">MediaItem</a>
     *
     * @param options Per-call playback options, see [PlaybackOptions]. The SDK keeps no state for
     * them, so the same SDK instance can hand out an offline MediaItem and a streaming one
     * without being released and recreated.
     *
     * @throws [WvException.ContentDataException] if the contentData is wrong
     * @throws [WvException.DetectedDeviceTimeModifiedException] if the device time manipulation error
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.DetectedDeviceTimeModifiedException::class
    )
    fun getMediaItem(options: PlaybackOptions): MediaItem

    /**
     * Get a [DataSource.Factory].
     * Play content via pass to ExoPlayer.
     *
     * Same as [getDataSourceFactory] with [PlaybackOptions.DEFAULT]: downloaded content is read
     * from the download cache when available.
     *
     * @see <a href="https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/upstream/DataSource.Factory.html">DataSource.Factory</a>
     */
    fun getDataSourceFactory(): DataSource.Factory

    /**
     * Get a [DataSource.Factory].
     * Play content via pass to ExoPlayer.
     *
     * With [PlaybackOptions.forceStreaming] the download cache is bypassed and the content is
     * always fetched from the remote streaming URL, even if it has been downloaded. Otherwise
     * downloaded content is read from the download cache.
     *
     * @param options Per-call playback options, see [PlaybackOptions]. The SDK keeps no state for
     * them, so the same SDK instance can hand out an offline DataSource.Factory and a streaming
     * one without being released and recreated.
     *
     * @see <a href="https://exoplayer.dev/doc/reference/com/google/android/exoplayer2/upstream/DataSource.Factory.html">DataSource.Factory</a>
     */
    fun getDataSourceFactory(options: PlaybackOptions): DataSource.Factory

    /**
     * Get a [DownloadState].
     *
     * @return content download state [DownloadState]
     */
    fun getDownloadState(): DownloadState

    /**
     * Get a KeySetId, the ID of the downloaded content.
     * If the content was not downloaded, null is returned.
     *
     * @return the ID of the downloaded content.
     */
    fun getKeySetId(): ByteArray?

    /**
     * Get a [DrmSessionManager].
     * that is ready to communicate with the DoveRunner server
     * DrmSessionManager can be managed directly by the customer.
     *
     * Same as [getDrmSessionManager] with [PlaybackOptions.DEFAULT]: if an offline license has
     * been downloaded, the returned manager plays with it (no license server request), matching
     * the behavior of [getMediaSource] and [getMediaItem].
     *
     * @return Manages a DRM session [DrmSessionManager]
     */
    fun getDrmSessionManager(): DrmSessionManager

    /**
     * Get a [DrmSessionManager].
     * that is ready to communicate with the DoveRunner server
     * DrmSessionManager can be managed directly by the customer.
     *
     * With [PlaybackOptions.forceStreaming] a fresh license is always requested from the license
     * server. Otherwise, if an offline license has been downloaded, the returned manager uses it
     * so playback works without a network connection.
     *
     * The same manager instance is returned while the resolved offline license stays the same, so
     * re-preparing the same player (e.g. calling setMediaItem() again after onResume) reuses the
     * DRM sessions that are already loaded instead of requesting a new license — important when
     * the license token has a short validity. A recreated player is detected automatically and
     * transparently gets a fresh internal manager; in that case a new license request is made, so
     * issue a new token before re-preparing if the previous one may have expired.
     *
     * @param options Per-call playback options, see [PlaybackOptions]. The SDK keeps no state for
     * them, so the same SDK instance can hand out an offline DrmSessionManager and a streaming one
     * without being released and recreated.
     *
     * @return Manages a DRM session [DrmSessionManager]
     */
    fun getDrmSessionManager(options: PlaybackOptions): DrmSessionManager

    /**
     * As each patch progresses, you can check to see if you need to migrate.
     *
     * @throws [WvException.ContentDataException] if contentData is wrong
     *
     * @return true if this is content that needs to be migrated, false otherwise.
     */
    @Throws(
        WvException.ContentDataException::class
    )
    fun needsMigrateDownloadedContent(): Boolean

    /**
     * Migrate past downloaded content
     * If the url value of contentData is a local address, contentName is empty, and downloadedFolderName is null, migration proceeds to the url value of contentData.
     *
     * @param contentName Content name which will be used for the name of downloaded content folder
     * @param downloadedFolderName Content download folder name
     *
     * @throws [WvException.ContentDataException] if contentData is wrong
     * @throws [WvException.MigrationException] if migration error
     * @throws [WvException.MigrationLocalPathException] When the localPath of ContentData and the path of the downloaded content are the same or a subdirectory
     *
     * @return true if the migration is successful, false otherwise.
     */
    @Throws(
        WvException.ContentDataException::class,
        WvException.MigrationException::class,
        WvException.MigrationLocalPathException::class
    )
    fun migrateDownloadedContent(
        contentName: String,
        downloadedFolderName: String?
    ): Boolean

    /**
     * Try when all DRM content suddenly fails to play on the device and there is an error like the one below.
     * Failed to restore keys: General DRM error (-2000)
     *
     * This error can occur when there is a problem with provisioning and can be reset.
     * You must be connected to the network when using the function.
     *
     * @param onSuccess Called when a problem occurs during a certificate re-request.
     * @param onFailed [WvException.DrmException]
     *
     */
    fun reProvisionRequest(onSuccess: (() -> Unit), onFailed: ((WvException) -> Unit))

    /**
     * Get a [DownloadManager].
     *
     * @return download manager [DownloadManager]
     */
    @Deprecated(
        message = "This function is deprecated and will be removed in the next release",
        replaceWith = ReplaceWith("DrWvSDK.getDownloadManager(Context)"),
        level = DeprecationLevel.WARNING
    )
    fun getDownloadManager(context: Context, dummy: Unit? = null): DownloadManager

    fun setPlayer(player: Player)

    @Keep
    companion object {
        /**
         * Get a [DrWvSDK].
         *
         * @param context Interface to global information about an application environment.
         * @param contentData Content classes for downloads and DRM. [ContentData]
         *
         * @return sdk object [DrWvSDK]
         */
        @Deprecated(
            message = "This function is deprecated and will be removed in the next release",
            replaceWith = ReplaceWith("DrWvSDK.createWvSDK(context, contentData)"),
            level = DeprecationLevel.WARNING
        )
        @JvmStatic
        fun createPallyConWvSDK(
            context: Context,
            contentData: ContentData
        ): DrWvSDK {
            return DrWvSDKImpl.createWvSDK(
                context,
                contentData
            )
        }

        /**
         * Get a [DrWvSDK].
         *
         * @param context Interface to global information about an application environment.
         * @param contentData Content classes for downloads and DRM. [ContentData]
         *
         * @return sdk object [DrWvSDK]
         */
        @JvmStatic
        fun createWvSDK(
            context: Context,
            contentData: ContentData
        ): DrWvSDK {
            return DrWvSDKImpl.createWvSDK(
                context,
                contentData
            )
        }

        /**
         * Set a download director for contents.
         *
         * @param context Interface to global information about an application environment.
         * @param directoryPath Path of download directory
         */
        @JvmStatic
        fun setDownloadDirectory(context: Context, directoryPath: String) {
            DrWvSDKImpl.setDownloadDirectory(context, directoryPath)
        }

        /**
         * Set a [WvCallback]
         *
         * @param wvCallback The callback to be added.
         */
        @Deprecated(
            message = "This function is deprecated and will be removed in the next release",
            replaceWith = ReplaceWith("DrWvSDK.setWvCallback(wvCallback)"),
            level = DeprecationLevel.WARNING
        )
        @JvmStatic
        fun setPallyConCallback(wvCallback: WvCallback?) {
            DrWvSDKImpl.setWvCallback(wvCallback)
        }

        @JvmStatic
        fun setWvCallback(wvCallback: WvCallback?) {
            DrWvSDKImpl.setWvCallback(wvCallback)
        }

        /**
         * Sets the user's DownloadService associated with download notifications.
         *
         * @param service the [DownloadService] class user created.
         */
        @JvmStatic
        fun setDownloadService(service: Class<out DownloadService?>?) {
            DrWvSDKImpl.setDownloadService(service)
        }

        /**
         * Add a [WvEventListener]
         *
         * @param wvEventListener The listener to be added.
         */
        @Deprecated(
            message = "This function is deprecated and will be removed in the next release",
            replaceWith = ReplaceWith("DrWvSDK.addWvEventListener(wvEventListener)"),
            level = DeprecationLevel.WARNING
        )
        @JvmStatic
        fun addPallyConEventListener(wvEventListener: WvEventListener) {
            DrWvSDKImpl.addWvEventListener(wvEventListener)
        }

        @JvmStatic
        fun addWvEventListener(wvEventListener: WvEventListener) {
            DrWvSDKImpl.addWvEventListener(wvEventListener)
        }

        /**
         * Remove a [WvEventListener]
         *
         * @param wvEventListener The listener to be removed.
         */
        @Deprecated(
            message = "This function is deprecated and will be removed in the next release",
            replaceWith = ReplaceWith("DrWvSDK.removeWvEventListener(wvEventListener)"),
            level = DeprecationLevel.WARNING
        )
        @JvmStatic
        fun removePallyConEventListener(wvEventListener: WvEventListener) {
            DrWvSDKImpl.removeWvEventListener(wvEventListener)
        }

        /**
         * Remove a [WvEventListener]
         *
         * @param wvEventListener The listener to be removed.
         */
        @JvmStatic
        fun removeWvEventListener(wvEventListener: WvEventListener) {
            DrWvSDKImpl.removeWvEventListener(wvEventListener)
        }

        /**
         * Get a [DownloadManager].
         *
         * @return download manager [DownloadManager]
         */
        @JvmStatic
        fun getDownloadManager(context: Context): DownloadManager {
            return DrWvSDKImpl.getDownloadManager(context)
        }

        /**
         * Set a [CmcdConfiguration.Factory]
         *
         * Function used to enable cmcd information to the CDN.
         * The CDN must support this feature
         *
         * @param CmcdConfiguration.Factory factory for CmcdConfiguration instances.
         */
        @JvmStatic
        fun setCmcdConfigurationFactory(factory: CmcdConfiguration.Factory?) {
            DrWvSDKImpl.setCmcdConfigurationFactory(factory)
        }
    }
}
