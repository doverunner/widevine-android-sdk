package com.doverunner.widevine.drm

import com.google.gson.annotations.SerializedName

/** @suppress */
data class WvLicenseServerError(
    @field:SerializedName("body") val body: String?,
    @field:SerializedName("errorCode") val errorCode: Int?,
    @field:SerializedName("message") val message: String?
)