package com.doverunner.widevine.drm

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Pair
import androidx.media3.common.Format
import androidx.media3.common.util.Util
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.analytics.PlayerId
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.DrmSession
import androidx.media3.exoplayer.drm.DrmSessionEventListener
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.drm.DummyExoMediaDrm
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.OfflineLicenseHelper
import androidx.media3.exoplayer.drm.UnsupportedDrmException
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import com.doverunner.widevine.cmcd.CmcdManager
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.model.DrmInformation
import com.doverunner.widevine.util.DeviceInfo
import com.doverunner.widevine.util.GlobalObjectUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** @suppress */
class WvLicenseManager(
    private val context: Context,
    private val contentData: ContentData,
    factory: OkHttpDataSource.Factory,
) {
    private var offlineLicenseHelper: OfflineLicenseHelper
    private var wvMediaDrmCallback: WvMediaDrmCallback = WvMediaDrmCallback(context, factory)
    private var drmEventDispatcher = DrmSessionEventListener.EventDispatcher()
    private var handler: Handler? = null// = Util.createHandlerForCurrentLooper()
    private var playbackDrmSession: ReusableDrmSessionManager? = null
    private var playbackKeySetId: ByteArray? = null

    init {
        val deviceInfo = DeviceInfo.getDeviceInfo()
        contentData.drmConfig?.let {
            wvMediaDrmCallback.setDrmServerRequestHeader(
                contentData,
                deviceInfo
            )
        }

        wvMediaDrmCallback.addEventLicenseServerException {
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, it)
            }
        }

        wvMediaDrmCallback.addEventWvException {
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, it)
            }
        }

        offlineLicenseHelper = OfflineLicenseHelper(
            createDrmSessionManager(),
            drmEventDispatcher
        )

        try {
            handler = Util.createHandlerForCurrentLooper()
        } catch (e: IllegalStateException) {
            print(e.message)
        }

        if (handler == null) {
            handler = Util.createHandlerForCurrentOrMainLooper()
        }

        drmEventDispatcher.addEventListener(handler!!, object: DrmSessionEventListener {
            override fun onDrmKeysLoaded(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmKeysLoaded(windowIndex, mediaPeriodId)
                print("onDrmKeysLoaded")
            }

            override fun onDrmKeysRemoved(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmKeysRemoved(windowIndex, mediaPeriodId)
                print("onDrmKeysRemoved")
            }

            override fun onDrmKeysRestored(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmKeysRestored(windowIndex, mediaPeriodId)
                print("onDrmKeysRestored")
            }

            override fun onDrmSessionAcquired(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
                state: Int,
            ) {
                super.onDrmSessionAcquired(windowIndex, mediaPeriodId, state)
                print("onDrmSessionAcquired")
            }

            override fun onDrmSessionManagerError(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
                error: java.lang.Exception,
            ) {
                super.onDrmSessionManagerError(windowIndex, mediaPeriodId, error)
                print("onDrmSessionManagerError")
//                pallyConEventListener?.onFailed(contentData.url,
//                    PallyConException.DrmException("DRM error. ${error.message}"))
            }

            override fun onDrmSessionReleased(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmSessionReleased(windowIndex, mediaPeriodId)
                print("onDrmSessionReleased")
            }
        })
    }

    fun createDrmSessionManager(): DefaultDrmSessionManager =
        createDrmSessionManager(wvMediaDrmCallback, loadErrorHandlingPolicy = null)

    private fun createDrmSessionManager(
        callback: WvMediaDrmCallback,
        loadErrorHandlingPolicy: LoadErrorHandlingPolicy?,
    ): DefaultDrmSessionManager {
        return DefaultDrmSessionManager.Builder()
            .setUuidAndExoMediaDrmProvider(
                contentData.drmConfig!!.uuid
            ) { uuid ->
                try {
                    // Force L3.
//                    mediaDrm.setPropertyString("securityLevel", "L3")
                    return@setUuidAndExoMediaDrmProvider FrameworkMediaDrm.newInstance(uuid)
                } catch (e: UnsupportedDrmException) {
                    return@setUuidAndExoMediaDrmProvider DummyExoMediaDrm()
                }
            }
            .setMultiSession(true)
            .apply { loadErrorHandlingPolicy?.let { setLoadErrorHandlingPolicy(it) } }
            .build(callback)
    }

    // Removing a license is best-effort: the local keys are invalidated as soon as the release
    // challenge is generated, so the server notification must not inherit the download path's
    // patience (10s timeouts x 3 retries, 40s+ worst case). One attempt, hard-capped at 5s.
    private val releaseLicenseHelper: OfflineLicenseHelper by lazy {
        val releaseFactory = OkHttpDataSource.Factory(
            OkHttpClient.Builder()
                .connectTimeout(3, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .callTimeout(5, TimeUnit.SECONDS)
                .build()
        )
        val releaseCallback = WvMediaDrmCallback(context, releaseFactory)
        contentData.drmConfig?.let {
            releaseCallback.setDrmServerRequestHeader(contentData, DeviceInfo.getDeviceInfo())
        }
        releaseCallback.addEventLicenseServerException {
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, it)
            }
        }
        releaseCallback.addEventWvException {
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, it)
            }
        }
        OfflineLicenseHelper(
            createDrmSessionManager(releaseCallback, DefaultLoadErrorHandlingPolicy(0)),
            drmEventDispatcher
        )
    }

    fun getPlaybackDrmSession(offlineKeySetId: ByteArray? = null): DrmSessionManager {
        // ExoPlayer must get the same manager instance back on every re-prepare of the same
        // player: the keepalive key cache lives inside DefaultDrmSessionManager, and a fresh
        // instance always re-requests a license, which fails once a short-lived token expires.
        // A new instance is handed out only when the offline key set changes — setMode() requires
        // a manager with no live sessions, and sources already holding the old instance keep a
        // matching prepare/release pairing with it.
        val current = playbackDrmSession
        if (current == null || !playbackKeySetId.contentEquals(offlineKeySetId)) {
            playbackDrmSession = ReusableDrmSessionManager(offlineKeySetId)
            playbackKeySetId = offlineKeySetId
        }
        return playbackDrmSession!!
    }

    // The download and track-lookup paths pin the manager to their own DownloadHelper thread,
    // so they must never share the playback instance.
    fun getOneShotDrmSession(): DrmSessionManager = createDrmSessionManager()

    fun resetPlaybackDrmSession() {
        // Called when the downloaded content or its license is removed: the cached manager still
        // carries pre-removal session state (setMode key set, keepalive sessions), and a request
        // built on it confuses the license server. Only the cache reference is dropped — a player
        // still holding the old instance keeps its prepare/release pairing; the next playback
        // starts from a clean manager.
        playbackDrmSession = null
        playbackKeySetId = null
    }

    /**
     * Keeps one stable [DrmSessionManager] identity for playback while managing the underlying
     * [DefaultDrmSessionManager] instances Media3 actually requires: each one pins itself to the
     * first playback looper it sees, so one delegate is kept per player looper and calls are
     * routed by the calling thread. This preserves the keepalive key cache across re-prepares of
     * the same player (no license re-request) and keeps the prepare/release pairing correct both
     * when a player is recreated and when two players play at once from one SDK instance.
     */
    private inner class ReusableDrmSessionManager(
        private val offlineKeySetId: ByteArray?,
    ) : DrmSessionManager {
        private val delegates = ConcurrentHashMap<Looper, DefaultDrmSessionManager>()

        // Fallback for callers off the playback thread (e.g. preacquireSession from a loading
        // thread); with a single active player this is always the right delegate.
        @Volatile
        private var lastDelegate: DefaultDrmSessionManager? = null

        @Volatile
        private var warnedMultiplePlayers = false

        private fun newDelegate(): DefaultDrmSessionManager {
            return createDrmSessionManager().also { manager ->
                offlineKeySetId?.let {
                    manager.setMode(DefaultDrmSessionManager.MODE_PLAYBACK, it)
                }
            }
        }

        private fun delegateForCurrentThread(): DefaultDrmSessionManager {
            Looper.myLooper()?.let { delegates[it] }?.let { return it }
            return lastDelegate
                ?: delegates.getOrPut(Looper.myLooper() ?: Looper.getMainLooper()) { newDelegate() }
        }

        override fun setPlayer(playbackLooper: Looper, playerId: PlayerId) {
            // Delegates of released players hold no MediaDrm resources; dropping them only
            // keeps the map from growing.
            delegates.keys.removeAll { !it.thread.isAlive }
            val delegate = delegates.getOrPut(playbackLooper) { newDelegate() }
            if (delegates.size > 1 && !warnedMultiplePlayers) {
                warnedMultiplePlayers = true
                Log.w(
                    "WvLicenseManager",
                    "Multiple players are sharing one DrWvSDK instance. Playback still works " +
                            "but each player requests its own license; create one DrWvSDK " +
                            "instance per player instead."
                )
            }
            lastDelegate = delegate
            delegate.setPlayer(playbackLooper, playerId)
        }

        override fun prepare() {
            delegateForCurrentThread().prepare()
        }

        override fun release() {
            // Strict routing: releasing a delegate that never saw the matching prepare would
            // corrupt its reference count.
            Looper.myLooper()?.let { delegates[it] }?.release()
        }

        override fun preacquireSession(
            eventDispatcher: DrmSessionEventListener.EventDispatcher?,
            format: Format,
        ): DrmSessionManager.DrmSessionReference =
            delegateForCurrentThread().preacquireSession(eventDispatcher, format)

        override fun acquireSession(
            eventDispatcher: DrmSessionEventListener.EventDispatcher?,
            format: Format,
        ): DrmSession? = delegateForCurrentThread().acquireSession(eventDispatcher, format)

        override fun getCryptoType(format: Format): Int =
            delegateForCurrentThread().getCryptoType(format)
    }

    fun downloadLicense(
        format: Format,
        onSuccess: ((ByteArray) -> Unit)?,
        onFailed: ((WvException.DrmException) -> Unit)?,
    ) {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val licenseData = offlineLicenseHelper.downloadLicense(format)
                onSuccess?.invoke(licenseData)
            } catch (e: DrmSession.DrmSessionException) {
                onFailed?.invoke(WvException.DrmException(e, "DrmSession Exception : " + e.message))
            } catch (e: java.lang.NullPointerException) {
                onFailed?.invoke(WvException.DrmException(e, "Download License Exception"))
            } catch (e: java.lang.Exception) {
                onFailed?.invoke(WvException.DrmException(e, "Download License Exception"))
            } finally {
                CmcdManager.getInstance().flushOnce()
            }
        }
    }

    fun getDrmInformation(keySetId: ByteArray): DrmInformation {
        try {
            val licenseDurationRemainingSec: Pair<Long, Long> =
                offlineLicenseHelper.getLicenseDurationRemainingSec(keySetId)

            return DrmInformation(
                licenseDurationRemainingSec.first,
                licenseDurationRemainingSec.second
            )
        } catch (e: DrmSession.DrmSessionException) {
            throw WvException.DrmException(e, "Problem with DRM : ${e.message}")
        } catch (e: Exception) {
            throw WvException.DrmException(e, "Problem with DRM : ${e.message}")
        }
    }

    fun renewDrmLicense(keySetId: ByteArray): ByteArray {
        try {
            return offlineLicenseHelper.renewLicense(keySetId)
        } catch (e: DrmSession.DrmSessionException) {
            throw WvException.DrmException(e, "failed renew drm license : ${e.message}")
        } catch (e: Exception) {
            throw WvException.DrmException(e, "failed renew drm license : ${e.message}")
        }
    }

    fun removeDrmLicense(keySetId: ByteArray) {
        try {
            releaseLicenseHelper.releaseLicense(keySetId)
        } catch (e: DrmSession.DrmSessionException) {
            // 6004 is Media3's ERROR_CODE_DRM_LICENSE_ACQUISITION_FAILED: the server rejected the
            // release or the network failed. The local keys are already invalidated at this point,
            // so the lost server notification is accepted as a best-effort miss.
            if (e.errorCode != 6004) {
                throw WvException.DrmException(e, "failed remove drm license : ${e.message}")
            }
        } catch (e: Exception) {
            throw WvException.DrmException(e, "failed remove drm license : ${e.message}")
        }
    }
}