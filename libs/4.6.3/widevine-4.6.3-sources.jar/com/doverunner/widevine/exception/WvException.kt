package com.doverunner.widevine.exception

sealed class WvException(val e: Exception?, val msg: String): RuntimeException() {
    class DetectedDeviceTimeModifiedException(e: Exception?, msg: String) : WvException(e, msg)

    class NetworkConnectedException(e: Exception?, msg: String) : WvException(e, msg)

    /**
     * The cause of a [DownloadException], so callers can tell a missing content from a
     * content that exists but could not be deleted.
     */
    enum class DownloadErrorReason {
        /** The download record or the content file to remove does not exist. */
        NOT_FOUND,

        /** The content exists but could not be deleted (permission, file in use, I/O error). */
        REMOVE_FAILED,

        /** The cause is not specified. */
        UNKNOWN,
    }

    class DownloadException @JvmOverloads constructor(
        e: Exception?,
        msg: String,
        /**
         * Why the content could not be removed. Only remove() and removeAll() report
         * [DownloadErrorReason.NOT_FOUND] or [DownloadErrorReason.REMOVE_FAILED]; every other
         * API leaves this as [DownloadErrorReason.UNKNOWN].
         */
        val reason: DownloadErrorReason = DownloadErrorReason.UNKNOWN,
    ) : WvException(e, msg)

    class DrmException(e: Exception?, msg: String) : WvException(e, msg)

    /**
     * There is no downloaded license to operate on: it was never downloaded, or it has already
     * been removed. `removeLicense()` reports this instead of a generic [DrmException] so an app
     * retrying a removal can treat it as already completed.
     */
    class LicenseNotFoundException(e: Exception?, msg: String) : WvException(e, msg)

    class ContentDataException(e: Exception?, msg: String) : WvException(e, msg)

    class MigrationException(e: Exception?, msg: String) : WvException(e, msg)

    class MigrationLocalPathException(e: Exception?, msg: String) : WvException(e, msg)

    class WvLicenseCipherException(e: Exception?, msg: String): WvException(e, msg)

    class ClearKeyLicenseException(e: Exception?, msg: String) : WvException(e, msg)

    fun message(): String {
        return message ?: msg
    }
}