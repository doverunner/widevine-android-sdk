package com.doverunner.widevine.exception

class WvLicenseServerException(
    private val body: String,
    private val errorCode: Int,
    override val message: String?
): RuntimeException() {
    fun message(): String {
        return message ?: ""
    }

    fun body(): String {
        return body
    }

    fun errorCode(): Int {
        return errorCode
    }
}