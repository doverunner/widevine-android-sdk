package com.doverunner.widevine.util

import android.content.Context
import android.net.ConnectivityManager
import android.os.Build
import android.util.Base64
import org.json.JSONObject

/** @suppress */
class DeviceInfo {
    companion object {
        fun getDeviceInfo(): String {
            val version = Build.VERSION.RELEASE + "(" + Build.VERSION.SDK_INT + ")"
            val jsonData = JSONObject()
            val jsonBody = JSONObject()
            jsonBody.put("device_model", Build.MODEL)
            jsonBody.put("os_version", version)
            jsonData.put("device_info", jsonBody)
            return Base64.encodeToString(jsonData.toString().toByteArray(), Base64.NO_WRAP)
        }

        fun isConnectedNetwork(context: Context): Boolean {
            val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            return manager.isDefaultNetworkActive
        }
    }
}