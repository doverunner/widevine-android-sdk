package com.doverunner.widevine.util

import okhttp3.Interceptor
import okhttp3.Response

/** @suppress */
class CustomInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()

        // CMCD 헤더가 있는지 확인
        val cmcdHeader = originalRequest.header("CMCD-Session")

        if (cmcdHeader != null) {
            // CMCD 헤더가 있는 경우에만 처리
            val originalUrl = originalRequest.url
            val urlBuilder = originalUrl.newBuilder()

            // CMCD 헤더를 파싱하고 URL 파라미터로 추가
//            cmcdHeader.split(',').forEach { pair ->
//                val (key, value) = pair.split('=')
//                urlBuilder.addQueryParameter(key.trim(), value.trim().removeSurrounding("\""))
//                println("Adding CMCD parameter to URL: $key = $value")
//            }

//            originalRequest.headers.forEach { (name, value) ->
//                urlBuilder.addQueryParameter(name.trim(), value.trim().removeSurrounding("\""))
//            }

            val concatenatedValues = StringBuilder()

            originalRequest.headers.forEach { (_, value) ->
                concatenatedValues.append(value.trim().removeSurrounding("\"")).append(",")
            }

            // 마지막에 붙은 콤마를 제거
            if (concatenatedValues.isNotEmpty()) {
                concatenatedValues.setLength(concatenatedValues.length - 1)
                // 고정된 키로 모든 값을 쿼리 파라미터에 추가
                urlBuilder.addQueryParameter("CMCD", concatenatedValues.toString())
            }

            val newUrl = urlBuilder.build()

            val newRequest = originalRequest.newBuilder()
                .url(newUrl)
                .build()


            // 요청 헤더 출력 (CMCD 제외)
//            newRequest.headers.forEach { (name, value) ->
//                println("Header: $name = $value")
//            }

            // 요청 바디 (POST, PUT 등)
            val requestBody = newRequest.body
            if (requestBody != null) {
                val buffer = okio.Buffer()
                requestBody.writeTo(buffer)
                val requestBodyString = buffer.readUtf8()
                println("Request Body: $requestBodyString")
            }

            return chain.proceed(newRequest)
        } else {
            // CMCD 헤더가 없는 경우 원래 요청을 그대로 진행
            return chain.proceed(originalRequest)
        }
    }
}