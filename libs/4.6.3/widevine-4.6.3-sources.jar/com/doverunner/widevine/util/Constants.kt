package com.doverunner.widevine.util

/** @suppress */
object Constants {
    const val DR_LA_URL = "https://drm-license.doverunner.com/ri/licenseManager.do/"
    const val DRM_TYPE = "Widevine"
    const val PREFERENCES_STORE_NAME = "DrDataStore"
    const val DR_CUSTOM_DATA_HEADER = "pallycon-customdata-v2"
    const val DR_DEVICE_INFO_HEADER = "pallycon-client-meta"
}