package com.doverunner.widevine.cmcd

/** @suppress */
data class SdkEvent(
    val ts: Long,
    val event: String, // ps|e|t|c|b|m|pe|pc
    val sta: String? = null,                // s|p|r|a|e|f
    val ec: String? = null,                 // Event=e 일 때
    val pt: Long? = null,
    val bg: Boolean? = null,
    val bs: Boolean? = null,
    val eventKey: String? = null,         // User wants to pass this
    val msgType: String? = null,          // User wants to pass this
    val drmErrorCode: String? = null,  // User wants to pass this
    val serverResponseCode: String? = null, // User wants to pass this
    val custom: Map<String, String>? = null // 역-DNS 커스텀 키
)