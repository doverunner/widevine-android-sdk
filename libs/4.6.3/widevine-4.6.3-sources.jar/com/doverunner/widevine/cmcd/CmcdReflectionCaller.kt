package com.doverunner.widevine.cmcd

import android.content.Context
import androidx.media3.common.Player
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.Continuation
import kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED
import java.lang.reflect.Constructor
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** @suppress */
object CmcdReflectionCaller {
    fun callCmcdSdkFactoryCreate(
        context: Context,
        endpoint: String,
        bearer: String?,
        apiKey: String?
    ): Any? {
        try {
            val cmcdSdkFactoryClass: Class<*> = Class.forName("com.doverunner.cmcd.sdk.CmcdSdkFactory")
            val cmcdDependenciesClass: Class<*> = Class.forName("com.doverunner.cmcd.sdk.CmcdDependencies")

            val constructorParameterTypes = arrayOf(
                Context::class.java,
                String::class.java, // endpoint
                String::class.java, // bearer: String?
                String::class.java, // apiKey: String?

                Class.forName("okhttp3.OkHttpClient"), // OkHttpClient (from OkHttp library)
                Class.forName("kotlinx.serialization.json.Json"), // Json (from kotlinx.serialization library)
                kotlinx.coroutines.CoroutineScope::class.java, // ioScope (from kotlinx.coroutines)
                Class.forName("com.doverunner.cmcd.domain.port.EventStore"), // EventStore (assuming it's in cmcd.sdk)
                Class.forName("com.doverunner.cmcd.domain.port.Transport")  // Transport (assuming it's in cmcd.sdk)
            )

            val cmcdDependenciesConstructor: Constructor<*> = cmcdDependenciesClass.getConstructor(*constructorParameterTypes)
            val cmcdDependenciesInstance: Any = cmcdDependenciesConstructor.newInstance(
                context,
                endpoint,
                bearer,      // 사용자 정의 값
                apiKey,      // 사용자 정의 값
                null,        // okHttpClient (기본값 null)
                null,        // json (기본값 null)
                null,        // ioScope (기본값 null)
                null,        // eventStore (기본값 null)
                null         // transport (기본값 null)
            )
            val createMethod: Method = cmcdSdkFactoryClass.getMethod("create", cmcdDependenciesClass)
            val cmcdSdkInstance: Any? = createMethod.invoke(null, cmcdDependenciesInstance)
            return cmcdSdkInstance
        } catch (e: Exception) {
//            e.printStackTrace()
            return null
        }
    }

    // --- 비-suspend 함수 리플렉션 호출 유틸리티 ---
    private fun invokeNonSuspendMethod(
        instance: Any,
        methodName: String,
        parameterTypes: Array<Class<*>>,
        args: Array<Any?>
    ): Any? {
        try {
            val cmcdClass = Class.forName("com.doverunner.cmcd.sdk.CmcdSdkCore")
            val method = cmcdClass.getDeclaredMethod(methodName, *parameterTypes)
            method.isAccessible = true
            return method.invoke(instance, *args)
        } catch (e: NoSuchMethodException) {
//            throw IllegalStateException("don't find method $methodName", e)
            return null
        } catch (e: InvocationTargetException) {
//            throw e.targetException ?: e
            return null
        } catch (e: Exception) {
//            throw IllegalStateException("'$methodName' error reflection", e)
            return null
        }
    }

    private suspend fun <T> invokeSuspendMethod(
        instance: Any,
        methodName: String,
        parameterTypes: Array<Class<*>>,
        args: Array<Any?>
    ): T {
        val cmcdClass = Class.forName("com.doverunner.cmcd.sdk.CmcdSdkCore")
        val methodParams = parameterTypes.toMutableList().apply { add(Continuation::class.java) }.toTypedArray()

        val method = try {
            cmcdClass.getDeclaredMethod(methodName, *methodParams)
        } catch (e: NoSuchMethodException) {
//            throw IllegalStateException("The method '$methodName' could not be found. The suspend function has a Continuation parameter.", e)
            @Suppress("UNCHECKED_CAST")
            return null as T
        }

        method.isAccessible = true

        return suspendCancellableCoroutine { continuation ->
            val invocationArgs = args.toMutableList().apply { add(continuation) }.toTypedArray()
            try {
                val result = method.invoke(instance, *invocationArgs)
                if (result != COROUTINE_SUSPENDED) {
                    @Suppress("UNCHECKED_CAST")
                    continuation.resume(result as T)
                }
            } catch (e: InvocationTargetException) {
                @Suppress("UNCHECKED_CAST")
                continuation.resume(null as T)
//                continuation.resumeWithException(e.targetException ?: e)
            } catch (e: Throwable) {
                @Suppress("UNCHECKED_CAST")
                continuation.resume(null as T)
//                continuation.resumeWithException(e)
            }
        }
    }

    fun callAttachReflected(sdk: Any, player: Player) {
        invokeNonSuspendMethod(sdk, "attach", arrayOf(Player::class.java), args = arrayOf(player))
    }

    fun callSetContentIdReflected(sdk: Any, cid: String) {
        invokeNonSuspendMethod(sdk, "setContentId", arrayOf(String::class.java), args = arrayOf(cid))
    }

    fun callSetAuthDataReflected(sdk: Any, authData: String) {
        invokeNonSuspendMethod(sdk, "setAuthData", arrayOf(String::class.java), args = arrayOf(authData))
    }

    fun callSetVersionReflected(sdk: Any, version: String) {
        invokeNonSuspendMethod(sdk, "setVersion", arrayOf(String::class.java), args = arrayOf(version))
    }

    suspend fun callRecordReflected(sdk: Any, event: SdkEvent) {
        val eventKlass = Class.forName("com.doverunner.cmcd.domain.model.Event")
        val ctor = eventKlass.getConstructor(
            java.lang.Long.TYPE,            // ts: long
            String::class.java,             // event
            String::class.java,             // sta
            String::class.java,             // ec
            java.lang.Long::class.java,     // pt (boxed for nullable)
            java.lang.Boolean::class.java,  // bg
            java.lang.Boolean::class.java,  // bs
            String::class.java,             // eventKey
            String::class.java,             // msgType
            String::class.java,             // drmErrorCode  <-- 매핑 주의
            String::class.java,             // serverResponseCode
            Map::class.java                 // custom
        )

        // 필드 매핑: serverErrorCode -> drmErrorCode
        val domainEvent = ctor.newInstance(
            event.ts,
            event.event,
            event.sta,
            event.ec,
            event.pt,
            event.bg,
            event.bs,
            event.eventKey,
            event.msgType,
            event.drmErrorCode,
            event.serverResponseCode,
            event.custom
        )

        invokeSuspendMethod<Unit>(sdk, "record", arrayOf(eventKlass), args = arrayOf(domainEvent))
    }

    suspend fun callFlushOnceReflected(sdk: Any): Boolean {
        val result = invokeSuspendMethod<Boolean>(sdk, "flushOnce", emptyArray(), emptyArray())
        return result
    }
}
