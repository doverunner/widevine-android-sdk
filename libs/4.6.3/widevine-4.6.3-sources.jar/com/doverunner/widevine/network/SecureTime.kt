package com.doverunner.widevine.network

import androidx.media3.common.C
import androidx.media3.exoplayer.upstream.Loader
import java.util.*
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/** @suppress */
class SecureTime() {
    val list : List<String> = listOf("time.android.com", "time.google.com", "time.windows.com", "time.kriss.re.kr")
    private lateinit var loader: Loader
    private val client = SNTPClient()

    fun getTimeGMT(): Long {
        for (host in list) {
            if (client.requestTime(host, 3000)) {
                val time = client.ntpTime
                if (time != C.TIME_UNSET) {
                    return time
                }
            }
        }

        return 0L
    }

    suspend fun getTime(host: String): Long {
        return suspendCoroutine { continuation ->
            val client = SNTPClient()
            client.requestTime(host, 3000)
            continuation.resume(client.ntpTime)

//            val client = SNTPClient(object: SNTPClient.Listener  {
//                override fun onTimeResponse(rawDate: String?, date: Date?, ex: Exception?) {
//                    TODO("Not yet implemented")
//                }
//            })
//
//            client.requestTime(host, 3000)

//            SntpClient.initialize(null, object: SntpClient.InitializationCallback {
//                override fun onInitialized() {
//                    continuation.resume(SntpClient.getElapsedRealtimeOffsetMs())
//                }
//
//                override fun onInitializationFailed(error: IOException) {
//                    continuation.resume(C.TIME_UNSET)
//                }
//            })
        }
    }

    companion object {
        fun convertLongToGMT(t_value: Long): String {
            val cal = Calendar.getInstance()
            cal.timeInMillis = t_value// * 1000
            cal.timeZone = TimeZone.getTimeZone("GMT")
            return String.format(
                "%04d-%02d-%02dT%02d:%02d:%02dZ",
                cal[Calendar.YEAR], cal[Calendar.MONTH] + 1,
                cal[Calendar.DAY_OF_MONTH], cal[Calendar.HOUR_OF_DAY],
                cal[Calendar.MINUTE], cal[Calendar.SECOND]
            )
        }
    }
}