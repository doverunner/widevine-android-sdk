package com.doverunner.widevine.model

import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.exception.WvLicenseServerException

interface WvEventListener {
    /**
     * called when the download is completed
     *
     * @param contentData ContentData of downloading content
     */
    fun onCompleted(contentData: ContentData) {}

    /**
     * called on download progressed by 1% when called percentage increase
     *
     * @param contentData     ContentData of downloading content
     * @param percent         total progress of download (percent)
     * @param downloadedBytes total size(Byte) of the file
     */
    fun onProgress(contentData: ContentData, percent: Float, downloadedBytes: Long) {}

    /**
     * called when the download is stop
     *
     * @param contentData ContentData of downloading content
     */
    fun onStopped(contentData: ContentData) {}

    /**
     * called on re-start download
     *
     * @param contentData ContentData of downloading content
     */
    fun onRestarting(contentData: ContentData) {}

    /**
     * called on remove download
     *
     * @param contentData ContentData of downloading content
     */
    fun onRemoved(contentData: ContentData) {}

    /**
     * called on pause download
     *
     * @param currentUrl ContentData of downloading content
     */
    fun onPaused(contentData: ContentData) {}

    /**
     * called when an error occurs inside the SDK.
     * ex) content downloading occurs error, device time modified ..
     *
     * @param contentData ContentData of downloading content
     * @param e          [WvException]
     */
    fun onFailed(contentData: ContentData, e: WvException?) {}

    /**
     * called when an error occurs in the PallyCon DRM server.
     *
     * @param contentData ContentData of downloading content
     * @param e          [WvLicenseServerException]
     */
    fun onFailed(contentData: ContentData, e: WvLicenseServerException?) {}
}
