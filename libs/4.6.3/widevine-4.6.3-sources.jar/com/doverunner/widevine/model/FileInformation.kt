package com.doverunner.widevine.model

import androidx.media3.datasource.cache.Cache

data class FileInformation(
    /**
     * downloaded file size.
     */
    val downloadedFileSize: Long,
    /**
     * downloaded file directory cache.
     */
    val downloadedFileCache: Cache?,
    /**
     * downloaded directory.
     */
    val downloadedFileDirectory: java.io.File?
)