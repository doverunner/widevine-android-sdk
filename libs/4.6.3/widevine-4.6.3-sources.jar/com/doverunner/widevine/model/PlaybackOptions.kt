package com.doverunner.widevine.model

/**
 * Per-call playback options for [com.doverunner.widevine.sdk.DrWvSDK.getMediaSource] and
 * [com.doverunner.widevine.sdk.DrWvSDK.getMediaItem].
 *
 * These are playback-only settings. They are not part of [ContentData] on purpose: they describe
 * how a single playback should behave, not what the content is or how it is fetched, and the
 * download APIs (download, remove, downloadLicense, removeLicense, ...) do not consider them.
 *
 * The SDK keeps no state for these options. They apply to the getMediaSource() / getMediaItem()
 * call they are passed to, so a single SDK instance can hand out an offline MediaSource and a streaming one
 * (e.g. as a fallback when the offline license turned out to be expired) without being released
 * and recreated.
 *
 * Build one with [Builder], or use [DEFAULT] for plain playback:
 * ```
 * PlaybackOptions.Builder()
 *     .setForceStreaming(true)
 *     .build()
 * ```
 */
class PlaybackOptions private constructor(
    /**
     * If true, the MediaSource is always built from the remote streaming URL and a fresh license
     * is always requested from the license server, even if the content and an offline license have
     * already been downloaded. Any downloaded offline license is left untouched in local storage,
     * it is just not used for this MediaSource.
     */
    val forceStreaming: Boolean,
) {
    class Builder {
        private var forceStreaming: Boolean = false

        fun setForceStreaming(forceStreaming: Boolean) = apply {
            this.forceStreaming = forceStreaming
        }

        fun build(): PlaybackOptions = PlaybackOptions(forceStreaming)
    }

    companion object {
        /** Default playback: use downloaded content and its offline license when available. */
        @JvmField
        val DEFAULT: PlaybackOptions = Builder().build()
    }
}
