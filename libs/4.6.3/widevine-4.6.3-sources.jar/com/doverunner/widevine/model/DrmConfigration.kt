package com.doverunner.widevine.model

import android.os.Parcel
import android.os.ParcelUuid
import android.os.Parcelable
import androidx.media3.common.C
import com.doverunner.widevine.util.Constants.DR_LA_URL
import com.doverunner.widevine.exception.WvException
import kotlinx.parcelize.Parceler
import kotlinx.parcelize.Parcelize
import java.util.*

/**
 * A Config class for acquire license
 */
@Parcelize
data class DrmConfigration(
    /** A SiteID information obtained from the PallyCon admin. */
    val siteId: String,
    /** A SiteKey information obtained from the PallyCon admin. */
    val siteKey: String? = null,
    /**
     * A Token required for license acquisition.
     * have to customData or token
     */
    val token: String? = null,
    /** A customData required for license acquisition. */
    val customData: String? = null,
    /** A custom header required for license acquisition. */
    val httpHeaders: MutableMap<String?, String?>? = null,
    /** The cookie information required for license acquisition. */
    val cookie: String? = null,
    /** Set to true if you want to communicate with the server using the PallyCon License Cipher feature.
     * For more information, please send a request to PallyCon.
     * */
    val licenseCipherPath: String? = null,
    /** The URL is the domain address to try to obtain a license.  */
    val drmLicenseUrl: String = DR_LA_URL,
    /** UUID for the DRM scheme. */
    val uuid: UUID = C.WIDEVINE_UUID
): Parcelable {
    class Builder() {
        private var siteId: String? = null
        private var siteKey: String? = null
        private var token: String? = null
        private var customData: String? = null
        private var httpHeaders: MutableMap<String?, String?>? = null
        private var cookie: String? = null
        private var licenseCipherPath: String? = null
        private var drmLicenseUrl: String? = null
        private var uuid: UUID? = null

        constructor(siteId: String, token: String) : this() {
            this.siteId = siteId
            this.token = token
        }

        fun setSiteId(siteId: String) = apply { this.siteId = siteId }
        fun setSiteKey(siteKey: String?) = apply { this.siteKey = siteKey }
        fun setToken(token: String?) = apply { this.token = token }
        fun setCustomData(customData: String?) = apply { this.customData = customData }
        fun setHttpHeaders(httpHeaders: MutableMap<String?, String?>?) = apply { this.httpHeaders = httpHeaders }
        fun addHttpHeader(key: String?, value: String?) = apply {
            if (this.httpHeaders == null) {
                this.httpHeaders = mutableMapOf()
            }
            this.httpHeaders?.put(key, value)
        }
        fun setCookie(cookie: String?) = apply { this.cookie = cookie }
        fun setLicenseCipherPath(licenseCipherPath: String?) = apply { this.licenseCipherPath = licenseCipherPath }
        fun setDrmLicenseUrl(drmLicenseUrl: String?) = apply { this.drmLicenseUrl = drmLicenseUrl }
        fun setUuid(uuid: UUID) = apply { this.uuid = uuid }

        fun build(): DrmConfigration {
            val siteId = this.siteId ?: "FIXD"
            if (token == null && customData == null) {
                throw WvException.ContentDataException(null,
                    "you have to input the token or customData")
            }
            val drmLicenseUrl = this.drmLicenseUrl ?: DR_LA_URL
            val uuid = this.uuid ?: C.WIDEVINE_UUID

            return DrmConfigration(
                siteId,
                siteKey,
                token,
                customData,
                httpHeaders,
                cookie,
                licenseCipherPath,
                drmLicenseUrl,
                uuid
            )
        }
    }

    constructor(token: String) : this(
        "FIXD",
        null,
        token,
        null,
        null,
        null,
        null,
        DR_LA_URL,
        C.WIDEVINE_UUID
    )

    constructor(siteId: String, token: String) : this(
        siteId,
        null,
        token,
        null,
        null,
        null,
        null,
        DR_LA_URL,
        C.WIDEVINE_UUID
    )

    private companion object : Parceler<DrmConfigration> {
        override fun DrmConfigration.write(parcel: Parcel, flags: Int) {
            parcel.writeString(siteId)
            parcel.writeString(siteKey)
            parcel.writeString(token)
            parcel.writeString(customData)
            httpHeaders?.let {
                parcel.writeInt(it.size)
                it.forEach { (key, value) ->
                    parcel.writeString(key)
                    parcel.writeString(value)
                }
            } ?: run {
                parcel.writeInt(0)
            }
            parcel.writeString(cookie)
            parcel.writeString(licenseCipherPath)
            parcel.writeString(drmLicenseUrl)
            parcel.writeParcelable(ParcelUuid(uuid), flags)
        }

        override fun create(parcel: Parcel): DrmConfigration {
            val siteId = parcel.readString() ?: throw WvException.ContentDataException(null,
                "siteId is not defined")
            val siteKey = parcel.readString()
            val token = parcel.readString()
            val customData = parcel.readString()
            if (token == null && customData == null) {
                throw WvException.ContentDataException(null,
                    "you have to input the token or customData")
            }

            val mapLength = parcel.readInt()
            var httpHeaders: MutableMap<String?, String?>? = null
            if (mapLength > 0) {
                httpHeaders = mutableMapOf<String?, String?>().apply {
                    for (i in 0 until mapLength) {
                        this[parcel.readString()] = parcel.readString()
                    }
                }
            }
            val cookie = parcel.readString()
            val licenseCipherPath = parcel.readString()
            val drmLicenseUrl = parcel.readString() ?: DR_LA_URL

            val uuid = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                parcel.readParcelable<ParcelUuid>(ParcelUuid::class.java.classLoader, ParcelUuid::class.java)
            } else {
                @Suppress("DEPRECATION")
                parcel.readParcelable<ParcelUuid>(ParcelUuid::class.java.classLoader)
            } ?: throw WvException.ContentDataException(null, "have to uuid")

//            val uuid = parcel.readParcelable<ParcelUuid>(ParcelUuid::class.java.classLoader)
//                ?: throw PallyConException.DrmException("have to uuid")

//            val uuid = parcel.readValue(ParcelUuid::class.java.classLoader) as ParcelUuid

            return DrmConfigration(
                siteId,
                siteKey,
                token,
                customData,
                httpHeaders,
                cookie,
                licenseCipherPath,
                drmLicenseUrl,
                uuid.uuid
            )
        }
    }
}