package com.doverunner.widevine.model;

import android.os.Parcel
import android.os.Parcelable
import com.doverunner.widevine.exception.WvException
import kotlinx.parcelize.Parceler
import kotlinx.parcelize.Parcelize

@Parcelize
data class ContentData(
    /**
     * The Content ID.
     * If you don't enter a CID, the content is managed based on the URL.
     */
    var contentId: String? = null,
    /**
     * The URL pointing to the media stream.
     */
    var url: String? = null,
    /**
     * A Config class for acquire license
     */
    var drmConfig: DrmConfigration? = null,
    /**
     * The cookie information required to download content.
     */
    var cookie: String? = null,
    /**
     * A custom header required to access content.
     */
    var httpHeaders: MutableMap<String?, String?>? = null,
) : Parcelable {
    class Builder() {
        constructor(url: String, drmConfig: DrmConfigration) : this() {
            this.url = url
            this.drmConfig = drmConfig
        }

        private var url: String? = null
        private var drmConfig: DrmConfigration? = null
        private var contentId: String? = null
        private var cookie: String? = null
        private var httpHeaders: MutableMap<String?, String?>? = null

        fun setContentId(contentId: String?) = apply { this.contentId = contentId }
        fun setCookie(cookie: String?) = apply { this.cookie = cookie }
        fun setHttpHeaders(httpHeaders: Map<String?, String?>?) = apply {
            this.httpHeaders = httpHeaders?.toMutableMap()
        }

        fun addHttpHeader(key: String?, value: String?) = apply {
            if (this.httpHeaders == null) {
                this.httpHeaders = mutableMapOf()
            }
            this.httpHeaders?.put(key, value)
        }

        fun build(): ContentData {
            val url =
                this.url ?: throw WvException.ContentDataException(null, "url must not be empty")
            val drmConfig = this.drmConfig
                ?: throw WvException.ContentDataException(null, "drmConfig must not be empty")

            return ContentData(contentId, url, drmConfig, cookie, httpHeaders)
        }
    }

    constructor(url: String, drmConfig: DrmConfigration) : this() {
        this.contentId = null
        this.url = url
        this.drmConfig = drmConfig
        this.cookie = null
        this.httpHeaders = null
    }

    private companion object : Parceler<ContentData> {
        override fun ContentData.write(parcel: Parcel, flags: Int) {
            parcel.writeString(contentId)
            parcel.writeString(url)
            parcel.writeParcelable(drmConfig, flags)
            parcel.writeString(cookie)
            httpHeaders?.let {
                parcel.writeInt(it.size)
                it.forEach { (key, value) ->
                    parcel.writeString(key)
                    parcel.writeString(value)
                }
            } ?: run {
                parcel.writeInt(0)
            }
        }

        override fun create(parcel: Parcel): ContentData {
            val cid = parcel.readString()
            val url = parcel.readString()
//            val drmConfig = parcel.readParcelable<PallyConDrmConfigration>(PallyConDrmConfigration::class.java.classLoader)
            val drmConfig =
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    parcel.readParcelable(
                        DrmConfigration::class.java.classLoader,
                        DrmConfigration::class.java
                    )
                } else {
                    @Suppress("DEPRECATION")
                    parcel.readParcelable(DrmConfigration::class.java.classLoader)
                }
            val cookie = parcel.readString()

            val mapLength = parcel.readInt()
            var httpHeaders: MutableMap<String?, String?>? = null
            if (mapLength > 0) {
                httpHeaders = mutableMapOf<String?, String?>().apply {
                    for (i in 0 until mapLength) {
                        this[parcel.readString()] = parcel.readString()
                    }
                }
            }
            return ContentData(
                cid,
                url,
                drmConfig,
                cookie,
                httpHeaders
            )
        }
    }
}
