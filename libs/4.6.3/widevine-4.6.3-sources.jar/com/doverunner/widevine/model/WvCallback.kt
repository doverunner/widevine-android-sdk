package com.doverunner.widevine.model

import com.doverunner.widevine.sdk.DrWvSDK

interface WvCallback {
    /**
     * This function is called when you want to handle the license request part directly in your app.
     * You can modify that callback to include the part that communicates with the server when requesting a license upon registration.
     * [DrWvSDK.setPallyConCallback] register callback
     *
     * @param contentData contentData
     * @param keyData challenge data for license
     * @param requestData HTTP request headers
     */
    fun executeKeyRequest(
        contentData: ContentData,
        keyData: ByteArray,
        requestData: Map<String, String>,
    ): ByteArray
}