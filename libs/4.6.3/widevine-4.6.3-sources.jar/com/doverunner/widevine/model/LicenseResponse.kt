package com.doverunner.widevine.model

import com.google.gson.annotations.SerializedName

/** @suppress */
data class LicenseResponse(
    @field:SerializedName("device_info") val deviceInfo: DeviceInfo,
    @field:SerializedName("license") val license: String,
    @field:SerializedName("persistent") val persistent: Boolean,
    @field:SerializedName("license_duration") val licenseDuration: Int,
    @field:SerializedName("rental_duration") val rentalDuration: Int,
    @field:SerializedName("playback_duration") val playbackDuration: Int,
    @field:SerializedName("renewal") val renewal: Boolean,
    @field:SerializedName("renewal_duration") val renewalDuration: Int
)
