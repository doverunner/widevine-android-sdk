package com.doverunner.widevine.model

/** Represents state of a download. */
enum class DownloadState {
    /** Download has not started yet. */
    NOT,
    /** The download is waiting to be started. */
    QUEUED,
    /** The download is stopped for a specified. */
    STOPPED,
    /** The download is currently started. */
    DOWNLOADING,
    /** The download completed. */
    COMPLETED,
    /** The download failed. */
    FAILED,
    /** The download is being removed. */
    REMOVING,
    /** The download will restart after all downloaded data is removed. */
    RESTARTING,
    /** The download paused. */
    PAUSED
}