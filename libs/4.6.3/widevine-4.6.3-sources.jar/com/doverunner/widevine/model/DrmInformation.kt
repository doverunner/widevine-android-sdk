package com.doverunner.widevine.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class DrmInformation (
    /**
     * The remaining license duration.
     */
    val licenseDuration: Long,
    /**
     * The remaining playback duration.
     */
    val playbackDuration: Long
) : Parcelable