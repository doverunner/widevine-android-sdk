package com.doverunner.widevine.db

/** @suppress */
interface SecureStorage {
    suspend fun putString(key: String, value: String)
    suspend fun getString(key: String): String?
    suspend fun putLong(key: String, value: Long)
    suspend fun getLong(key: String): Long
    suspend fun remove(key: String)
    suspend fun clear()
    suspend fun getAllStringEntries(): Map<String, String>
}