package com.doverunner.widevine.db

import android.content.Context
//import android.content.SharedPreferences
import android.os.SystemClock
import android.util.Log
//import androidx.security.crypto.EncryptedSharedPreferences
//import androidx.security.crypto.MasterKey
import com.doverunner.widevine.network.SecureTime
import com.doverunner.widevine.util.DeviceInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.*
//import javax.crypto.AEADBadTagException
import kotlin.collections.ArrayList

/** @suppress */
//class DBManager(private val context: Context) {
//    private var preferences: SharedPreferences
//
//    init {
//        preferences = EncryptedSharedPreferences.create(
//            context,
//            APP_FILE_NAME,
//            getMasterKey(context),
//            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
//            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
//        )
//    }
//
//
//    private fun getMasterKey(context: Context): MasterKey {
//        return MasterKey.Builder(context)
//            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
//            .build()
//    }
//
//    fun updateSecureTime(
//        onSuccess: (() -> Unit)?,
//        onError: (() -> Unit)?
//    ) {
//        if (isUpdating) {
//            return
//        }
//
//        CoroutineScope(Dispatchers.Default).launch {
//            isUpdating = true
//            try {
//                val secureTime = SecureTime()
//                val beforeTickCount = getSecureTickCount()
//                var currentTickCount = SystemClock.elapsedRealtime()
//
//                var beforeTickTime = getSecureTime()
//                var currentTickTime = 0L
//                Log.d(TAG, "GAP Tick Count current/before : " + (currentTickCount - beforeTickCount))
//
//                if (DeviceInfo.isConnectedNetwork(context)) {
//                    currentTickTime = secureTime.getTimeGMT()
//                    Log.d(TAG, "Current tick time has been checked by online!")
//                }
//
//                if (currentTickTime == 0L) {
//                    if (beforeTickCount > currentTickCount) { //Tick 신뢰성 깨짐
//                        currentTickCount = beforeTickCount
//                        Log.e(TAG, "TickCount reliability has been broken!")
//                    } else { // Tick 신뢰성 보장
//                        currentTickTime = beforeTickTime + (currentTickCount - beforeTickCount) / 1000
//                        Log.i(TAG, "Tick Count reliability has been maintained!")
//                    }
//                }
//
//                Log.d(TAG, "tick time : $currentTickTime GMT : " + SecureTime
//                    .convertLongToGMT(currentTickTime))
//
//                var localTickTime = Date().time
//                var storeTickTime: Long
//                var storeTickCount: Long
//                Log.d(TAG, "local time : $localTickTime GMT : " + SecureTime
//                    .convertLongToGMT(localTickTime))
//
//                if (localTickTime + 86400000 < currentTickTime) {
//                    Log.e(TAG, "The device time has been modified : gap = " + (localTickTime - currentTickTime))
//                    storeTickTime = currentTickTime
//                    storeTickCount = currentTickCount
//                    isModified = true
//                } else {
//                    Log.i(TAG, "The device time has not changed : gap = " + (localTickTime - currentTickTime))
//                    if (localTickTime < currentTickTime) {
//                        storeTickTime = currentTickTime
//                        Log.i(TAG, "Secure time has saved as currentTickTime : $currentTickTime")
//                    } else {
//                        storeTickTime = localTickTime
//                        Log.i(TAG, "Secure time has saved as localTickTime : $localTickTime")
//                    }
//                    storeTickCount = currentTickCount
//                    isModified = false
//                }
//
//                preferences.edit().putLong(SECURE_TICK_TIME, storeTickTime).apply()
//                preferences.edit().putLong(SECURE_TICK_COUNT, storeTickCount).apply()
//
//                Log.d(TAG, "Current tick time has been checked by offline : $storeTickTime")
//                Log.d(TAG, "Current tick Count has been checked by offline : $storeTickCount")
//
//                if (isModified) {
//                    onError?.invoke()
//                } else {
//                    onSuccess?.invoke()
//                }
//            } catch (e: AEADBadTagException) {
//                Log.e(TAG, "Failed to decrypt data: ${e.message}")
//                resetPreferences()
//                onError?.invoke()
//            } catch (e: Exception) {
//                Log.e(TAG, "An unexpected error occurred: ${e.message}")
//                onError?.invoke()
//            } finally {
//                isUpdating = false
//            }
//        }
//    }
//
//    fun getSecureTime(): Long {
//        return preferences.getLong(SECURE_TICK_TIME, 0)
//    }
//
//    fun getSecureTickCount(): Long {
//        return preferences.getLong(SECURE_TICK_COUNT, 0)
//    }
//
//    fun setOldContentLocalUrl(key: String, localUrl: String) {
//        preferences.edit().putString(key, localUrl).apply()
//    }
//
//    fun getOldContentLocalUrl(key: String): String {
//        return preferences.getString(key, "") ?: ""
//    }
//
//    fun changeUrlToKey(url: String, key: String) {
//        val oldLocalUrl = preferences.getString(url, "") ?: ""
//        if (oldLocalUrl.isNotEmpty()) {
//            preferences.edit().putString(key, oldLocalUrl).apply()
//        }
//    }
//
//    fun getOldAllContentLocalUrls(): ArrayList<String> {
//        val list = ArrayList<String>()
//        for (item in preferences.all) {
//            if (item.key != SECURE_TICK_TIME && item.key != SECURE_TICK_COUNT) {
//                item.value?.let {
//                    list.add(it.toString())
//                }
//            }
//        }
//        return list
//    }
//
//    fun removeOldContentLocalUrl(url: String) {
//        preferences.edit().remove(url).apply()
//    }
//
//    fun removeAllOldContents() {
//        val storeTickTime = preferences.getLong(SECURE_TICK_TIME, 0)
//        val storeTickCount = preferences.getLong(SECURE_TICK_COUNT, 0)
//        preferences.edit().clear().apply()
//        preferences.edit().putLong(SECURE_TICK_TIME, storeTickTime).apply()
//        preferences.edit().putLong(SECURE_TICK_COUNT, storeTickCount).apply()
//    }
//
//    fun resetPreferences() {
//        preferences.edit().clear().apply()
//        preferences = EncryptedSharedPreferences.create(
//            context,
//            APP_FILE_NAME,
//            getMasterKey(context),
//            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
//            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
//        )
//    }
//
//    companion object {
//        private const val TAG = "PallyConDBManager"
//        private const val APP_FILE_NAME = "pallycon_setting"
//        private const val SECURE_TICK_TIME = "secure_tick_time"
//        private const val SECURE_TICK_COUNT = "secure_tick_count"
//
//        private var instance: DBManager? = null
//        private var isUpdating = false
//
//        var isModified = false
//
//        fun getInstance(_context: Context): DBManager {
//            return instance ?: synchronized(this) {
//                instance ?: DBManager(_context).also {
//                    instance = it
//                }
//            }
//        }
//    }
//}

class DBManager(private val context: Context) {
    private val storage: SecureStorage
    private val migrationManager = StorageMigrationManager(context)

    companion object {
        private const val TAG = "DBManager"
        private const val SECURE_TICK_TIME = "secure_tick_time"
        private const val SECURE_TICK_COUNT = "secure_tick_count"

        private var instance: DBManager? = null
        private var isUpdating = false
        var isModified = false

        fun getInstance(_context: Context): DBManager {
            return instance ?: synchronized(this) {
                instance ?: DBManager(_context).also {
                    instance = it
                }
            }
        }
    }

    init {
        storage = initializeStorage()
    }

    private fun initializeStorage(): SecureStorage {
        return try {
            val modernStorage = KeystoreSecureStorage(context)

            // 마이그레이션 필요한지 확인
            runBlocking {
                if (migrationManager.shouldMigrate()) {
                    Log.d(TAG, "Migration needed, performing migration...")
                    val legacyStorage = LegacySecureStorage(context)
                    migrationManager.performMigration(legacyStorage, modernStorage)
                }
            }

            Log.d(TAG, "Using modern storage: Android Keystore + DataStore")
            modernStorage
        } catch (e: Exception) {
            Log.w(TAG, "Modern storage failed, using legacy: ${e.message}")
            LegacySecureStorage(context)
        }
    }

    // 간소화된 public API
    fun updateSecureTime(
        onSuccess: (() -> Unit)?,
        onError: (() -> Unit)?
    ) {
        if (isUpdating) return

        CoroutineScope(Dispatchers.Default).launch {
            isUpdating = true
            try {
                val secureTime = SecureTime()
                val beforeTickCount = getSecureTickCount()
                var currentTickCount = SystemClock.elapsedRealtime()
                var beforeTickTime = getSecureTime()
                var currentTickTime = 0L

                Log.d(TAG, "GAP Tick Count current/before : " + (currentTickCount - beforeTickCount))

                if (DeviceInfo.isConnectedNetwork(context)) {
                    currentTickTime = secureTime.getTimeGMT()
                    Log.d(TAG, "Current tick time has been checked by online!")
                }

                if (currentTickTime == 0L) {
                    if (beforeTickCount > currentTickCount) {
                        currentTickCount = beforeTickCount
                        Log.e(TAG, "TickCount reliability has been broken!")
                    } else {
                        currentTickTime = beforeTickTime + (currentTickCount - beforeTickCount) / 1000
                        Log.i(TAG, "Tick Count reliability has been maintained!")
                    }
                }

                val localTickTime = Date().time
                val storeTickTime: Long
                val storeTickCount: Long

                if (localTickTime + 86400000 < currentTickTime) {
                    Log.e(TAG, "The device time has been modified")
                    storeTickTime = currentTickTime
                    storeTickCount = currentTickCount
                    isModified = true
                } else {
                    Log.i(TAG, "The device time has not changed")
                    storeTickTime = if (localTickTime < currentTickTime) currentTickTime else localTickTime
                    storeTickCount = currentTickCount
                    isModified = false
                }

                // 통합된 저장 방식
                storage.putLong(SECURE_TICK_TIME, storeTickTime)
                storage.putLong(SECURE_TICK_COUNT, storeTickCount)

                if (isModified) {
                    onError?.invoke()
                } else {
                    onSuccess?.invoke()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in updateSecureTime: ${e.message}")
                onError?.invoke()
            } finally {
                isUpdating = false
            }
        }
    }

    fun getSecureTime(): Long = runBlocking {
        storage.getLong(SECURE_TICK_TIME)
    }

    fun getSecureTickCount(): Long = runBlocking {
        storage.getLong(SECURE_TICK_COUNT)
    }

    fun setOldContentLocalUrl(key: String, localUrl: String) {
        CoroutineScope(Dispatchers.Default).launch {
            storage.putString(key, localUrl)
        }
    }

    fun getOldContentLocalUrl(key: String): String = runBlocking {
        storage.getString(key) ?: ""
    }

    fun changeUrlToKey(url: String, key: String) {
        CoroutineScope(Dispatchers.Default).launch {
            val oldLocalUrl = storage.getString(url) ?: ""
            if (oldLocalUrl.isNotEmpty()) {
                storage.putString(key, oldLocalUrl)
            }
        }
    }

    fun getOldAllContentLocalUrls(): ArrayList<String> = runBlocking {
        ArrayList(storage.getAllStringEntries().values)
    }

    fun removeOldContentLocalUrl(url: String) {
        CoroutineScope(Dispatchers.Default).launch {
            storage.remove(url)
        }
    }

    fun removeAllOldContents() {
        CoroutineScope(Dispatchers.Default).launch {
            val tickTime = storage.getLong(SECURE_TICK_TIME)
            val tickCount = storage.getLong(SECURE_TICK_COUNT)

            storage.clear()

            // 시스템 데이터는 복원
            storage.putLong(SECURE_TICK_TIME, tickTime)
            storage.putLong(SECURE_TICK_COUNT, tickCount)
        }
    }

    fun resetPreferences() {
        CoroutineScope(Dispatchers.Default).launch {
            storage.clear()
            if (storage is KeystoreSecureStorage) {
                storage.clear()
            }
        }
    }
}