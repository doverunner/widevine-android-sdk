package com.doverunner.widevine.service

import android.app.Notification
import android.content.Context
import androidx.annotation.Keep
import androidx.annotation.StringRes
import androidx.media3.common.util.Util
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.PlatformScheduler
import androidx.media3.exoplayer.scheduler.Scheduler
import com.doverunner.widevine.R
import com.doverunner.widevine.util.DownloadManagerUtil

/** Download Service */

@Keep
open class DrmDownloadService constructor(
    foregroundNotificationId: Int = FOREGROUND_NOTIFICATION_ID,
    foregroundNotificationUpdateInterval: Long = DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    channelId: String? = DownloadManagerUtil.getInstance().getNotificationChannelId(),
    @StringRes channelNameResourceId: Int = R.string.exo_download_notification_channel_name,
    @StringRes channelDescriptionResourceId: Int = 0,
) : DownloadService(
    foregroundNotificationId,
    foregroundNotificationUpdateInterval,
    channelId,
    channelNameResourceId,
    channelDescriptionResourceId
) {
    override fun onDestroy() {
        clearDownloadManagerHelpers()
        super.onDestroy()
    }

    override fun getDownloadManager(): DownloadManager {
        //        val downloadNotificationHelper = DownloadManagerUtil
//            .getInstance(this).getDownloadNotificationHelper()

//        manager.addListener(
//            TerminalStateNotificationHelper(
//                this,
//                downloadNotificationHelper,
//                FOREGROUND_NOTIFICATION_ID + 1
//            )
//        )
        return DownloadManagerUtil.getInstance().getDownloadManager(this)
    }

    override fun getScheduler(): Scheduler? {
        return if (Util.SDK_INT >= 21) PlatformScheduler(this, JOB_ID) else null
    }

    override fun getForegroundNotification(
        downloads: List<Download>,
        notMetRequirements: Int,
    ): Notification {
        val downloadNotificationHelper: DownloadNotificationHelper = DownloadManagerUtil
            .getInstance().getDownloadNotificationHelper(this)

        return downloadNotificationHelper
            .buildProgressNotification(
                this,
                R.drawable.dr_ic_baseline_arrow_downward_24,
                null,  /* message= */
                null,
                mutableListOf(),
                notMetRequirements
            )
    }

    private class TerminalStateNotificationHelper(
        context: Context, notificationHelper: DownloadNotificationHelper, firstNotificationId: Int,
    ) :
        DownloadManager.Listener {
        private val context: Context
        private val notificationHelper: DownloadNotificationHelper
        private var nextNotificationId: Int
        override fun onDownloadChanged(
            downloadManager: DownloadManager, download: Download, finalException: Exception?,
        ) {
//            val notification = if (download.state == Download.STATE_COMPLETED) {
//                notificationHelper.buildDownloadCompletedNotification(
//                    context,
//                    R.drawable.pallycon_ic_baseline_done_24,  /* contentIntent= */
//                    null,
//                    Util.fromUtf8Bytes(download.request.data)
//                )
//            } else if (download.state == Download.STATE_FAILED) {
//                notificationHelper.buildDownloadFailedNotification(
//                    context,
//                    R.drawable.pallycon_ic_baseline_done_24,  /* contentIntent= */
//                    null,
//                    Util.fromUtf8Bytes(download.request.data)
//                )
//            } else {
//                return
//            }
//            NotificationUtil.setNotification(context, nextNotificationId++, notification)
        }

        init {
            this.context = context.applicationContext
            this.notificationHelper = notificationHelper
            nextNotificationId = firstNotificationId
        }
    }

    companion object {
        private val JOB_ID: Int = 1
        private val FOREGROUND_NOTIFICATION_ID: Int = FOREGROUND_NOTIFICATION_ID_NONE
//        var contentData: ContentData? = null

//        fun startService(context: Context, clazz: Class<out DownloadService?>?, contentData: ContentData) {
//            val intent = Intent(context, clazz).apply {
////                putExtra(EXTRA_CONTENT_DATA, contentData)
//                putExtra(KEY_FOREGROUND, true)
//                action = ACTION_INIT
//            }
////            this.contentData = contentData
//            Util.startForegroundService(context, intent)
//        }


//        private const val EXTRA_CONTENT_DATA = "contentData"
    }
}