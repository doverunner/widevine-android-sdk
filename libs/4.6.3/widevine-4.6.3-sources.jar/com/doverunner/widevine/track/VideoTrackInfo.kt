package com.doverunner.widevine.track;

import androidx.media3.common.Format

class VideoTrackInfo(var format: Format) : TrackInfo(format) {
    /**
     * width
     */
    var width: Int

    /**
     * height
     */
    var height: Int

    /**
     * maxInputSize
     */
    var maxInputSize: Int

    /**
     * frame rate.
     */
    var frameRate: Float

    init {
        width = format.width
        height = format.height
        maxInputSize = format.maxInputSize
        frameRate = format.frameRate
    }
}
