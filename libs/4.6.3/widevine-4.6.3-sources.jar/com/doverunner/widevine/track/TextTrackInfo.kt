package com.doverunner.widevine.track;

import androidx.media3.common.Format

class TextTrackInfo constructor(var format: Format) : TrackInfo(format)