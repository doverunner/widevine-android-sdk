package com.doverunner.widevine.track;

import androidx.annotation.Nullable
import androidx.media3.common.Format

open class TrackInfo internal constructor(format: Format) {
    /**
     * ID
     */
    @Nullable
    var id: String?

    /**
     * bitrate
     */
    var bitrate: Int

    /**
     * mimetype
     */
    @Nullable
    var sampleMimeType: String?

    /**
     * codec
     */
    @Nullable
    var codecs: String?

    /**
     * subtitle
     */
    @Nullable
    var language: String?

    /**
     * Set to true when you want to download the corresponding track
     */
    var isDownload: Boolean

    init {
        id = format.id
        codecs = format.codecs
        sampleMimeType = format.containerMimeType
        bitrate = format.bitrate
        language = format.language
        isDownload = false
    }
}
