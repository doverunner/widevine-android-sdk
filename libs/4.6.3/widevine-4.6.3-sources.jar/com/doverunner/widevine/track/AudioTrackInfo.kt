package com.doverunner.widevine.track;

import androidx.media3.common.Format

class AudioTrackInfo internal constructor(var format: Format) : TrackInfo(format) {
    /**
     * audio sample rate
     */
    var sampleRate: Int
    var maxInputSize: Int
    var channelCount: Int

    init {
        sampleRate = format.sampleRate
        maxInputSize = format.maxInputSize
        channelCount = format.channelCount
    }
}
