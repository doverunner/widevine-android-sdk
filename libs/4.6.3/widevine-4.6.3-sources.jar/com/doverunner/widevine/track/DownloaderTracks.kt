package com.doverunner.widevine.track;

class DownloaderTracks {
    /**
     * video tracks
     */
    var video: ArrayList<VideoTrackInfo>

    /**
     * audio tracks
     */
    var audio: ArrayList<AudioTrackInfo>

    /**
     * subtitle tracks
     */
    var text: ArrayList<TextTrackInfo>

    init {
        video = ArrayList<VideoTrackInfo>()
        audio = ArrayList<AudioTrackInfo>()
        text = ArrayList<TextTrackInfo>()
    }
}
