package com.doverunner.widevine.util

import android.content.Context
import androidx.media3.exoplayer.upstream.CmcdConfiguration
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.exception.WvLicenseServerException
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.model.WvCallback
import com.doverunner.widevine.model.WvEventListener
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CopyOnWriteArrayList

class GlobalObjectUtil {
    var wvEventListener: WvEventListener? = null
    var wvCallback: WvCallback? = null
    var cmcdConfigurationFactory: CmcdConfiguration.Factory? = null

    private val listeners = CopyOnWriteArrayList<WvEventListener>()
    var licenseCipher: Any? = null

    companion object {
        private var instance: GlobalObjectUtil? = null

        fun getInstance(): GlobalObjectUtil {
            return instance ?: synchronized(this) {
                instance ?: GlobalObjectUtil().also {
                    instance = it
                }
            }
        }

        fun release() {
            instance = null
        }

        fun fetchBytesFromHttpsUrl(contentData: ContentData): ByteArray {
            val url = URL(contentData.url!!)
            val connection = url.openConnection() as HttpURLConnection
            try {
                connection.connect()

                if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                    throw IOException("HTTP Error: ${connection.responseCode}")
                }

                contentData.cookie?.let { cookie ->
                    connection.setRequestProperty("Cookie", cookie)
                }

                contentData.httpHeaders?.let { headers ->
                    for ((key, value) in headers) {
                        connection.setRequestProperty(key, value)
                    }
                }

                val inputStream: InputStream = connection.inputStream
                val buffer = ByteArrayOutputStream()
                val data = ByteArray(1024)
                var bytesRead: Int

                while (inputStream.read(data, 0, data.size).also { bytesRead = it } != -1) {
                    buffer.write(data, 0, bytesRead)
                }

                return buffer.toByteArray()
            } finally {
                connection.disconnect()
            }
        }
    }

    fun setListener(eventListener: WvEventListener?) {
        wvEventListener = eventListener
        eventListener?.let { listener ->
            if (!listeners.contains(listener)) {
                addListener(listener)
            }
        }
    }

    fun setCallback(callback: WvCallback?) {
        wvCallback = callback
    }

    fun createLicenseCipher(context: Context, licenseCipherPath: String): Boolean {
        if (this.licenseCipher != null) {
            return true
        }

        return try {
            val licenseCipherClass = Class.forName("com.doverunner.drdlc.DRMLicenseCipher")
            val companionObject = licenseCipherClass.getField("Companion").get(null)
            val createMethod = companionObject.javaClass.getMethod("createLicenseCipher", Context::class.java, String::class.java)
            createMethod.isAccessible = true
            licenseCipher = createMethod.invoke(companionObject, context, licenseCipherPath)
            true
        } catch (e: ClassNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }

//    fun doCipher(input: ByteArray, output: ByteArray): Boolean {
//        return try {
//            val licenseCipher = this.licenseCipher ?: return false
//
//            val licenseCipherClass = Class.forName("com.doverunner.drdlc.DRMLicenseCipher")
//            val createMethod = licenseCipherClass.getDeclaredMethod("doCipher", ByteArray::class.java, ByteArray::class.java).apply {
//                isAccessible = true
//            }
//
//            createMethod.invoke(licenseCipher, input, output) as Boolean
//        } catch (e: ClassNotFoundException) {
//            false
//        } catch (e: Exception) {
//            false
//        }
//    }

    fun doCipher(input: ByteArray): ByteArray? {
        return try {
            val licenseCipher = this.licenseCipher ?: return null

            val licenseCipherClass = Class.forName("com.doverunner.drdlc.DRMLicenseCipher")
            val createMethod = licenseCipherClass.getDeclaredMethod("doCipher", ByteArray::class.java).apply {
                isAccessible = true
            }

            createMethod.invoke(licenseCipher, input)
        } catch (e: ClassNotFoundException) {
            null
        } catch (e: Exception) {
            null
        } as ByteArray?
    }

    fun addListener(listener: WvEventListener) {
        listeners.addIfAbsent(listener)
    }

    internal fun removeListener(listener: WvEventListener) {
        listeners.remove(listener)
    }

    internal fun notifyCompleted(contentData: ContentData) {
        listeners.forEach { it.onCompleted(contentData) }
    }

    internal fun notifyProgress(contentData: ContentData, percent: Float, downloadedBytes: Long) {
        listeners.forEach { it.onProgress(contentData, percent, downloadedBytes) }
    }

    internal fun notifyStopped(contentData: ContentData) {
        listeners.forEach { it.onStopped(contentData) }
    }

    internal fun notifyRestarting(contentData: ContentData) {
        listeners.forEach { it.onRestarting(contentData) }
    }

    internal fun notifyRemoved(contentData: ContentData) {
        listeners.forEach { it.onRemoved(contentData) }
    }

    internal fun notifyPaused(contentData: ContentData) {
        listeners.forEach { it.onPaused(contentData) }
    }

    internal fun notifyFailed(contentData: ContentData, e: WvException?) {
        listeners.forEach { it.onFailed(contentData, e) }
    }

    internal fun notifyFailed(contentData: ContentData, e: WvLicenseServerException?) {
        listeners.forEach { it.onFailed(contentData, e) }
    }
}