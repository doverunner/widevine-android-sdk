/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.doverunner.widevine;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.doverunner.widevine";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final long VERSION_CODE = 1L;
  // Field from default config.
  public static final String VERSION_NAME = "4.5.2";
}
