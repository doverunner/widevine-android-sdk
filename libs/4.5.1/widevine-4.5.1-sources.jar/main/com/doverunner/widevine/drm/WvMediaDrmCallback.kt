package com.doverunner.widevine.drm

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.util.Assertions
import androidx.media3.common.util.Util
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceInputStream
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.StatsDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.drm.ExoMediaDrm
import androidx.media3.exoplayer.drm.MediaDrmCallback
import androidx.media3.exoplayer.drm.MediaDrmCallbackException
import com.doverunner.widevine.cmcd.CmcdManager
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.exception.WvLicenseServerException
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.model.LicenseResponse
import com.doverunner.widevine.model.DrmServerResponse
import com.doverunner.widevine.util.Constants.DR_CLIENT_SESSION_ID_HEADER
import com.doverunner.widevine.util.Constants.DR_CUSTOM_DATA_HEADER
import com.doverunner.widevine.util.Constants.DR_DEVICE_INFO_HEADER
import com.doverunner.widevine.util.GlobalObjectUtil
import java.util.UUID

/** @suppress */
class WvMediaDrmCallback constructor(
    private val context: Context,
    private val factory: OkHttpDataSource.Factory,
) : MediaDrmCallback {

    private var contentData: ContentData? = null
    private var customData: String = ""
    private var deviceInfo: String = ""
    private var licenseServerCallback: ((WvLicenseServerException) -> Unit)? = null
    private var wvExceptionCallback: ((WvException) -> Unit)? =
        null

    companion object {
        private const val MAX_MANUAL_REDIRECTS = 5

        fun getRedirectUrl(
            exception: HttpDataSource.InvalidResponseCodeException, manualRedirectCount: Int,
        ): String? {
            // For POST requests, the underlying network stack will not normally follow 307 or 308
            // redirects automatically. Do so manually here.
            val manuallyRedirect = ((exception.responseCode == 307 || exception.responseCode == 308)
                    && manualRedirectCount < MAX_MANUAL_REDIRECTS)
            if (!manuallyRedirect) {
                return null
            }
            val headerFields = exception.headerFields
            val locationHeaders = headerFields["Location"]
            if (!locationHeaders.isNullOrEmpty()) {
                return locationHeaders[0]
            }
            return null
        }
    }

    fun setDrmServerRequestHeader(
        contentData: ContentData,
        deviceInfo: String,
    ) {
        this.contentData = contentData
        this.customData = contentData.drmConfig?.authData ?:
            contentData.drmConfig?.customData ?: contentData.drmConfig?.token ?: ""
        this.deviceInfo = deviceInfo
        contentData.drmConfig?.licenseCipherPath?.let {
            if (!GlobalObjectUtil.getInstance().createLicenseCipher(context, it)) {
                wvExceptionCallback?.invoke(
                    WvException.WvLicenseCipherException(null,
                        "failed createLicenseCipher. LicenseCipher requires an implementation to use it.")
                )
            }
        }
    }

    fun addEventLicenseServerException(
        callback: (WvLicenseServerException) -> Unit,
    ) {
        this.licenseServerCallback = callback
    }

    fun addEventWvException(
        callback: (WvException) -> Unit
    ) {
        this.wvExceptionCallback = callback
    }

    private fun hexStringToByteArray(hexString: String): ByteArray {
        val len = hexString.length
        val data = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            data[i / 2] = ((Character.digit(hexString[i], 16) shl 4) +
                    Character.digit(hexString[i + 1], 16)).toByte()
            i += 2
        }
        return data
    }

    private fun handleServerResponse(response: ByteArray): ByteArray {
        return when (val result = processServerResponse(response)) {
            is DrmServerResponse.Error -> {
                CmcdManager.getInstance().record(
                    msgType = "license-request",
                    event = "e",
                    drmErrorCode = result.error.errorCode.toString())
                handleError(result.error)
            }
            is DrmServerResponse.License ->  {
                CmcdManager.getInstance().record(
                    eventKey = "completed",
                    event = "k",
                    msgType = "license-request")
                hexStringToByteArray(result.license.license)
            }
            is DrmServerResponse.RawData -> {
                CmcdManager.getInstance().record(
                    eventKey = "completed",
                    event = "k",
                    msgType = "license-request")
                result.data
            }
        }
    }

    private fun handleError(error: WvLicenseServerError): ByteArray {
        val exception = WvLicenseServerException(
            body = error.body ?: "body is null",
            errorCode = error.errorCode ?: 0,
            message = error.message ?: "message is null"
        )

        licenseServerCallback?.invoke(exception)
        throw exception  // 또는 특정 에러 값을 반환
    }

    private fun processServerResponse(response: ByteArray): DrmServerResponse {
        return try {
            val responseString = String(response)
            val gson = Gson()

            when {
                isErrorResponse(responseString) ->
                    DrmServerResponse.Error(gson.fromJson(responseString, WvLicenseServerError::class.java))
                isLicenseResponse(responseString) ->
                    DrmServerResponse.License(gson.fromJson(responseString, LicenseResponse::class.java))
                else -> DrmServerResponse.RawData(response)
            }
        } catch (e: JsonSyntaxException) {
            DrmServerResponse.RawData(response)
        }
    }

    private fun isErrorResponse(responseString: String): Boolean {
        return responseString.contains("\"errorCode\"") || responseString.contains("\"message\"")
    }

    private fun isLicenseResponse(responseString: String): Boolean {
        return responseString.contains("\"license\"")
    }

    private fun executeRequest(contentData: ContentData, body: ByteArray, requestProperties: Map<String, String>): ByteArray {
        return GlobalObjectUtil.getInstance().wvCallback?.executeKeyRequest(
            contentData,
            body,
            requestProperties
        ) ?: run {
            val licenseUrl = contentData.drmConfig?.drmLicenseUrl
            if (licenseUrl.isNullOrEmpty()) {
                ByteArray(0)
            } else {
                executePost(factory, licenseUrl, body, requestProperties)
            }
        }

//        executePost(factory, contentData.drmConfig!!.drmLicenseUrl!!, body, requestProperties)
    }

    override fun executeKeyRequest(uuid: UUID, request: ExoMediaDrm.KeyRequest): ByteArray {
        CmcdManager.getInstance().record(
            eventKey = "started",
            event = "k",
            msgType = "license-request")

        if (contentData == null && contentData?.drmConfig?.drmLicenseUrl == null) {
            wvExceptionCallback?.invoke(
                WvException.ContentDataException(null, "check a contentData. ex. drmConfig")
            )
            return ByteArray(0)
        }

        val requestProperties: MutableMap<String, String> = HashMap()
        if (C.PLAYREADY_UUID == uuid) {
            requestProperties["Content-Type"] = "text/xml"
            requestProperties["SOAPAction"] =
                "http://schemas.microsoft.com/DRM/2007/03/protocols/AcquireLicense"
        } else if (C.CLEARKEY_UUID == uuid) {
            requestProperties["Content-Type"] = "application/json"
        } else {
            requestProperties["Content-Type"] = "application/octet-stream"
        }

        requestProperties[DR_CUSTOM_DATA_HEADER] = customData
        requestProperties[DR_DEVICE_INFO_HEADER] = deviceInfo

        if (CmcdManager.getInstance().getSessionId().isNotEmpty()) {
            requestProperties[DR_CLIENT_SESSION_ID_HEADER] = CmcdManager.getInstance().getSessionId()
        }

        contentData?.drmConfig?.httpHeaders?.let {
            for (entry in it) {
                if (entry.key != null && entry.value != null) {
                    requestProperties[entry.key!!] = entry.value!!
                }
            }
        }

        contentData?.drmConfig?.cookie?.let {
            requestProperties["Cookie"] = it
        }

        var body = request.data

        contentData?.drmConfig?.licenseCipherPath?.let {
            val globalInstance = GlobalObjectUtil.getInstance()
            val licenseCipher = globalInstance.licenseCipher

            if (licenseCipher != null) {
                val encryptedData = ByteArray(request.data.size)
                if (globalInstance.doCipher(request.data, encryptedData)) {
                    body = encryptedData
                } else {
                    wvExceptionCallback?.invoke(
                        WvException.WvLicenseCipherException(null, "failed encrypt for response")
                    )
                }
            } else {
                wvExceptionCallback?.invoke(
                    WvException.WvLicenseCipherException(null, "failed createLicenseCipher")
                )
            }
        }

        val response = executeRequest(contentData!!, body, requestProperties)
        return handleServerResponse(response)
    }

    override fun executeProvisionRequest(
        uuid: UUID,
        request: ExoMediaDrm.ProvisionRequest,
    ): ByteArray {
        val url: String =
            request.defaultUrl + "&signedRequest=" + Util.fromUtf8Bytes(request.data)
        return executePost(
            factory,
            url,
            null,
            emptyMap<String, String>()
        )
    }

    private fun executePost(
        dataSourceFactory: DataSource.Factory,
        url: String,
        httpBody: ByteArray?,
        requestProperties: Map<String, String>,
    ): ByteArray {
        val dataSource = StatsDataSource(dataSourceFactory.createDataSource())
        var manualRedirectCount = 0

        var dataSpec = DataSpec.Builder()
            .setUri(url)
            .setHttpRequestHeaders(requestProperties)
            .setHttpMethod(DataSpec.HTTP_METHOD_POST)
            .setHttpBody(httpBody)
            .setFlags(DataSpec.FLAG_ALLOW_GZIP)
            .build()
        val originalDataSpec = dataSpec
        try {
            while (true) {
                val inputStream = DataSourceInputStream(dataSource, dataSpec)
                try {
//                    return Util.toByteArray(inputStream)
                    return inputStream.readBytes()
                } catch (e: HttpDataSource.InvalidResponseCodeException) {
                    CmcdManager.getInstance().record(
                        eventKey = "error",
                        event = "e",
                        msgType = "license-request",
                        responseCode = e.responseCode.toString())
                    val redirectUrl = getRedirectUrl(e, manualRedirectCount) ?: throw e
                    manualRedirectCount++
                    dataSpec.buildUpon().setUri(redirectUrl).build()
                } finally {
                    Util.closeQuietly(inputStream)
                }
            }
        } catch (e: Exception) {
            throw MediaDrmCallbackException(
                originalDataSpec,
                Assertions.checkNotNull(dataSource.lastOpenedUri),
                dataSource.responseHeaders,
                dataSource.bytesRead,
                e
            )
        }
    }
}