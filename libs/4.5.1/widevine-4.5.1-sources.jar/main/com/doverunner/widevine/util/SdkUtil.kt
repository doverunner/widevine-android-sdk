package com.doverunner.widevine.util

import java.io.File
import java.net.URI

object SdkUtil {

    sealed class DeleteResult {
        object Success : DeleteResult()
        object Failed : DeleteResult()
        object InvalidPath : DeleteResult()
        object NotFound : DeleteResult()
        object NotDirectory : DeleteResult()
        object AccessDenied : DeleteResult()
        data class NotEmpty(val fileCount: Int) : DeleteResult()
    }

    @JvmStatic
    fun checkFileExists(fileUri: String): Boolean {
        return try {
            val uri = URI.create(fileUri)
            File(uri.path).exists()
        } catch (e: Exception) {
            false
        }
    }

    @JvmStatic
    fun getDirectoryFromFileUri(fileUri: String): String? {
        return try {
            val uri = URI.create(fileUri)
            if (uri.scheme == "file") {
                val file = File(uri.path)
                file.parent // 부모 디렉토리 경로 반환
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    @JvmStatic
    fun deleteDirectoryRecursively(fileUri: String): Boolean {
        if (!checkFileExists(fileUri)) {
            return false
        }

        val directoryPath = getDirectoryFromFileUri(fileUri) ?: return false
        val directory = File(directoryPath)
        return directory.deleteRecursively() // Kotlin 확장 함수
    }
}