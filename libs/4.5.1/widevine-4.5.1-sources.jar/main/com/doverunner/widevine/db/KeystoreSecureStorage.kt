package com.doverunner.widevine.db

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

class KeystoreSecureStorage(private val context: Context) : SecureStorage {
    private val keyManager = AndroidKeystoreManager(context)
    private val dataStore: DataStore<Preferences> by lazy { context.keystoreDataStore }

    private val Context.keystoreDataStore: DataStore<Preferences> by preferencesDataStore(
        name = "keystore_secure_storage"
    )

    override suspend fun putString(key: String, value: String) {
        val encrypted = keyManager.encrypt(value)
        dataStore.edit { preferences ->
            preferences[stringPreferencesKey(key)] = encrypted
        }
    }

    override suspend fun getString(key: String): String? {
        val encrypted = dataStore.data.first()[stringPreferencesKey(key)] ?: return null
        return try {
            keyManager.decrypt(encrypted)
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun putLong(key: String, value: Long) {
        dataStore.edit { preferences ->
            preferences[longPreferencesKey(key)] = value
        }
    }

    override suspend fun getLong(key: String): Long {
        return dataStore.data.first()[longPreferencesKey(key)] ?: 0L
    }

    override suspend fun remove(key: String) {
        dataStore.edit { preferences ->
            preferences.remove(stringPreferencesKey(key))
            preferences.remove(longPreferencesKey(key))
        }
    }

    override suspend fun clear() {
        dataStore.edit { it.clear() }
    }

    override suspend fun getAllStringEntries(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val preferences = dataStore.data.first()

        preferences.asMap().forEach { (key, value) ->
            if (value is String && !isSystemKey(key.name)) {
                try {
                    val decrypted = keyManager.decrypt(value)
                    result[key.name] = decrypted
                } catch (e: Exception) {
                    // 복호화 실패한 항목은 제외
                }
            }
        }
        return result
    }

    private fun isSystemKey(keyName: String): Boolean {
        return keyName in listOf("secure_tick_time", "secure_tick_count", "migration_completed")
    }
}
