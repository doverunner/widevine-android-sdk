package com.doverunner.widevine.db

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class LegacySecureStorage(private val context: Context) : SecureStorage {
    @Suppress("DEPRECATION")
    private val preferences: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "pallycon_setting",
        getMasterKey(context),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Suppress("DEPRECATION")
    private fun getMasterKey(context: Context): MasterKey {
        return MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    override suspend fun putString(key: String, value: String) {
        preferences.edit().putString(key, value).apply()
    }

    override suspend fun getString(key: String): String? {
        return preferences.getString(key, null)
    }

    override suspend fun putLong(key: String, value: Long) {
        preferences.edit().putLong(key, value).apply()
    }

    override suspend fun getLong(key: String): Long {
        return preferences.getLong(key, 0L)
    }

    override suspend fun remove(key: String) {
        preferences.edit().remove(key).apply()
    }

    override suspend fun clear() {
        preferences.edit().clear().apply()
    }

    override suspend fun getAllStringEntries(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        preferences.all.forEach { (key, value) ->
            if (value is String && !isSystemKey(key)) {
                result[key] = value
            }
        }
        return result
    }

    private fun isSystemKey(keyName: String): Boolean {
        return keyName in listOf("secure_tick_time", "secure_tick_count")
    }

    fun getAllEntries(): Map<String, *> = preferences.all
}