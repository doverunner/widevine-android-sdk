package com.doverunner.widevine.downloader

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.util.Util
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.hls.playlist.HlsMediaPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsMultivariantPlaylist
import androidx.media3.exoplayer.hls.playlist.HlsPlaylistParser
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.Download.FAILURE_REASON_NONE
import androidx.media3.exoplayer.offline.DownloadHelper
import androidx.media3.exoplayer.offline.DownloadIndex
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.WritableDownloadIndex
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.trackselection.MappingTrackSelector
import com.doverunner.widevine.db.DBManager
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.model.DownloadState
import com.doverunner.widevine.model.FileInformation
import com.doverunner.widevine.track.AudioTrackInfo
import com.doverunner.widevine.track.DownloaderTracks
import com.doverunner.widevine.track.TextTrackInfo
import com.doverunner.widevine.track.VideoTrackInfo
import com.doverunner.widevine.util.DownloadManagerUtil
import com.doverunner.widevine.util.GlobalObjectUtil
import com.doverunner.widevine.util.SdkUtil
import kotlinx.coroutines.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException
import java.util.UUID

/** @suppress */
class DownloadManager constructor(
    private val context: Context,
    private val contentData: ContentData,
    private val factory: HttpDataSource.Factory,
) {
    //    private var downloadManager: DownloadManager? = null
    private var downloadHelper: DownloadHelper? = null
    private var prepareHelper: DownloadHelper? = null
    private var mediaItem: MediaItem? = null

//    @Volatile
//    private var _downloadObject: Download? = null

    private var downloadIndex: DownloadIndex? = null
    private var job: Job? = null
    private var downloadService = DownloadManagerUtil.getInstance().downloadService

    init {
        contentData.url?.let {
            var mediaItemBuilder = MediaItem.Builder().setUri(it)
            contentData.mimeType?.let {
                mediaItemBuilder.setMimeType(it)
            }

            mediaItem = mediaItemBuilder.build()

            DownloadManagerUtil.getInstance()
                .addDownloadManagerListener(
                    contentData.contentId,
                    contentData.url!!,
                    object : DownloadManagerUtil.DownloadListener {
                        override fun onDownloadsChanged(
                            download: Download,
                            finalException: Exception?,
                        ) {
                            DownloadManagerUtil.getInstance()
                                .addDownload(contentData, download)

                            if (finalException != null) {
                                CoroutineScope(Dispatchers.Main).launch {
                                    GlobalObjectUtil.getInstance().notifyFailed(
                                        contentData,
                                        WvException.DownloadException(null, "finalException " + finalException.message)
                                        )
                                }
                            } else {
                                processListener(download)
                            }
                        }

                        override fun onDownloadRemoved(download: Download) {
//                            downloadObject = download
                            DownloadManagerUtil.getInstance()
                                .addDownload(contentData, download)
                        }
                    })
        }
        downloadIndex = DownloadManagerUtil.getInstance().getDownloadManager(context).downloadIndex
        loadDownload()
    }

    fun prepare(
        drmSessionManager: DrmSessionManager,
        onSuccess: ((DownloadHelper) -> Unit)?,
        onFailed: ((WvException) -> Unit)?,
    ) {
        if (prepareHelper != null) {
            return
        }

        if (downloadHelper != null) {
            onSuccess?.invoke(downloadHelper!!)
            return
        }

        if (mediaItem == null) {
            onFailed?.invoke(
                WvException.ContentDataException(null, "content url is null")
            )
            return
        }

        prepareHelper = DownloadHelper.Factory()
            .setDataSourceFactory(factory)
            .setTrackSelectionParameters(DefaultTrackSelector.Parameters.DEFAULT)
            .setRenderersFactory(DefaultRenderersFactory(context))
            .create(mediaItem!!);

        val callBack = object : DownloadHelper.Callback {
            override fun onPrepared(
                helper: DownloadHelper,
                tracksInfoAvailable: Boolean
            ) {
                prepareHelper = null
                downloadHelper = helper
                onSuccess?.invoke(helper)
            }

            override fun onPrepareError(helper: DownloadHelper, e: IOException) {
                prepareHelper = null
                var tempCause: Throwable? = e
                var isNetworkError = false
                while (tempCause?.cause != null) {
                    if (tempCause is UnknownHostException) {
                        isNetworkError = true
                        break
                    }
                    tempCause = tempCause.cause
                }

                if (isNetworkError) {
                    onFailed?.invoke(
                        WvException.NetworkConnectedException(null, "network not connected : " + e.message)
                    )
                } else {
                    onFailed?.invoke(
                        WvException.DownloadException(null, "download init error : " + e.message)
                    )
                }
            }
        }

        prepareHelper?.prepare(callBack)
    }

    fun release() {
        DownloadManagerUtil.getInstance().getDownloadManager(context).release()
        downloadHelper?.release()
        val util = DownloadManagerUtil.getInstance()
        util.release()
        util.removeDownloadManagerListener(contentData.contentId, contentData.url ?: "")
    }

    fun startDownload(downloaderTracks: DownloaderTracks, keySetId: ByteArray?) {
        val helper = downloadHelper
            ?: throw WvException.ContentDataException(null, "downloader object is null")

        val contentUrl = contentData.url
            ?: throw WvException.ContentDataException(null, "content url is null")

        var downloadData = contentData.contentId ?: contentUrl

        // 메인 스레드에서 실행되도록 보장
        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Track selection parameters 생성 및 적용 (메인 스레드에서)
                val trackSelectionParams = buildTrackSelectionParameters(context, helper, downloaderTracks)

                // 모든 period에 대해 기존 track selection 클리어
                for (periodIndex in 0 until helper.periodCount) {
                    helper.clearTrackSelections(periodIndex)
                }

                // 새로운 track selection parameters 적용
                for (periodIndex in 0 until helper.periodCount) {
                    helper.addTrackSelection(periodIndex, trackSelectionParams)
                }

                // Download request 생성 (메인 스레드에서)
                val downloadRequest = helper
                    .getDownloadRequest(downloadData, Util.getUtf8Bytes(downloadData))
                    .copyWithKeySetId(keySetId)

                // DownloadManager 호출 (백그라운드 스레드에서)
                withContext(Dispatchers.Default) {
                    DownloadManagerUtil.getInstance().getDownloadManager(context).addDownload(downloadRequest)
                }

            } catch (e: Exception) {
                // 메인 스레드에서 에러 처리
                GlobalObjectUtil.getInstance().notifyFailed(
                    contentData,
                    WvException.DownloadException(e, "Failed to configure track selection: ${e.message}")
                )
            }
        }
    }

    fun stop() {
        if (downloadHelper == null) {
            throw WvException.ContentDataException(null, "downloader object is null")
        }

        val contentUrl = contentData.url ?: throw WvException.ContentDataException(null, "content url is null")

        var downloadData = contentData.contentId ?: contentUrl
        DownloadManagerUtil.getInstance().getDownloadManager(context)
            .setStopReason(downloadData, 1)
//        DownloadService.sendSetStopReason(
//            context,
//            downloadService.downloadService,
//            downloadData,
//            1,
//            false
//        )
    }

    fun resumeAllDownload() {
//        DownloadService.sendResumeDownloads(context, downloadService.downloadService, false)
        DownloadManagerUtil.getInstance().getDownloadManager(context).resumeDownloads()
    }

    fun pauseAllDownload() {
//        DownloadService.sendPauseDownloads(
//            context, downloadService.downloadService, false
//        )
        DownloadManagerUtil.getInstance().getDownloadManager(context).pauseDownloads()
        CoroutineScope(Dispatchers.Main).launch {
            GlobalObjectUtil.getInstance().notifyPaused(contentData)
        }
    }

    fun resumeDownload() {
        if (DownloadManagerUtil.getInstance()
                .getDownload(contentData) == null) {
            throw WvException.DownloadException(null, "downloader object is null")
        }

        val contentUrl = contentData.url ?: throw WvException.ContentDataException(null, "content url is null")

        var downloadData = contentData.contentId ?: contentUrl
        DownloadManagerUtil.getInstance().getDownloadManager(context)
            .setStopReason(downloadData, Download.STOP_REASON_NONE)
    }

    fun removeDownload() {
        if (DownloadManagerUtil.getInstance()
                .getDownload(contentData) == null) {
            throw WvException.DownloadException(null, "downloader object is null")
        }

        val contentUrl = contentData.url ?: throw WvException.ContentDataException(null, "content url is null")

        var downloadData = contentData.contentId ?: contentUrl
        DownloadManagerUtil.getInstance().getDownloadManager(context).removeDownload(downloadData)

//        DownloadService.sendRemoveDownload(
//            context,
//            downloadService.downloadService,
//            downloadData,
//            false
//        )
    }

    fun removeAllDownload() {
        DownloadManagerUtil.getInstance().getDownloadManager(context).removeAllDownloads()
//        DownloadService.sendRemoveAllDownloads(
//            context,
//            downloadService.downloadService,
//            false
//        )
    }

    fun getDownloadState(): DownloadState {
        return if (!contentData.localFileUrl.isNullOrEmpty() &&
            SdkUtil.checkFileExists(contentData.localFileUrl!!)) {
            DownloadState.COMPLETED
        } else if (DownloadManagerUtil.getInstance()
                .getDownload(contentData) == null) {
            DownloadState.NOT
        } else {
            when (DownloadManagerUtil.getInstance()
                .getDownload(contentData)!!.state) {
                Download.STATE_QUEUED -> DownloadState.QUEUED
                Download.STATE_STOPPED -> DownloadState.STOPPED
                Download.STATE_DOWNLOADING -> DownloadState.DOWNLOADING
                Download.STATE_COMPLETED -> DownloadState.COMPLETED
                Download.STATE_FAILED -> DownloadState.FAILED
                Download.STATE_REMOVING -> DownloadState.REMOVING
                Download.STATE_RESTARTING -> DownloadState.RESTARTING
                else -> DownloadState.NOT
            }
        }
    }

    fun getDownloadRequest(): DownloadRequest? {
        if (DownloadManagerUtil.getInstance()
                .getDownload(contentData) == null) {
            return null
        }

        return DownloadManagerUtil.getInstance()
            .getDownload(contentData)!!.request
    }

    fun setLicenseData(keySetId: ByteArray) {
//        val download =
//            downloadObject ?: throw PallyConException.DownloadException("downloader object is null")
        val index: WritableDownloadIndex = DownloadManagerUtil.getInstance()
            .getDownloadManager(context).downloadIndex as WritableDownloadIndex
        val downloadObject = DownloadManagerUtil.getInstance()
            .getDownload(contentData)
        val download = if (downloadObject != null) {
            val request = downloadObject.request.copyWithKeySetId(keySetId)
            Download(
                request,
                downloadObject.state,
                downloadObject.startTimeMs,
                downloadObject.updateTimeMs,
                downloadObject.contentLength,
                downloadObject.stopReason,
                downloadObject.failureReason
            )
        } else {
            val startTimeMs = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
            val downloadData = contentData.contentId ?: contentData.url!!
            val downloadRequest = DownloadRequest.Builder(downloadData, Uri.parse(contentData.url))
                .setData(Util.getUtf8Bytes(downloadData))
                .build()
                .copyWithKeySetId(keySetId)
            Download(
                downloadRequest,
                Download.STATE_QUEUED,
                startTimeMs,
                startTimeMs + 3000,
                -1,
                0,
                FAILURE_REASON_NONE
            )
        }

        index.putDownload(download)
    }

    fun setLicenseForMigration(url: String, cid: String, keySetId: ByteArray, startTimeMs: Long) {
        val downloadRequest = DownloadRequest.Builder(cid, Uri.parse(url))
            .setData(Util.getUtf8Bytes(cid))
            .build().copyWithKeySetId(keySetId)

        val download = Download(
            downloadRequest,
            Download.STATE_COMPLETED,
            startTimeMs,
            startTimeMs + 3000,
            -1,
            0,
            FAILURE_REASON_NONE
        )

        (DownloadManagerUtil.getInstance()
            .getDownloadManager(context).downloadIndex as WritableDownloadIndex).let {
            it.putDownload(download)
//            downloadObject = download
            DownloadManagerUtil.getInstance()
                .addDownload(contentData, download)
        }
    }

    fun getAllDownloadKeySetIds(): List<ByteArray> {
        var returnList: MutableList<ByteArray> = mutableListOf()
        try {
            downloadIndex?.getDownloads().use { loadedDownloads ->
                if (loadedDownloads != null) {
                    while (loadedDownloads.moveToNext()) {
                        val download = loadedDownloads.download
                        download.request.keySetId?.let { returnList.add(it) }
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            print(e.message)
        } finally {
            return returnList
        }
    }

    private fun loadDownload() {
        try {
            downloadIndex?.getDownloads().use { loadedDownloads ->
                if (loadedDownloads != null) {
                    while (loadedDownloads.moveToNext()) {
                        val download = loadedDownloads.download
                        if (download.request.id == contentData.contentId) {
                            DownloadManagerUtil.getInstance()
                                .addDownload(contentData, download)
                        } else if (contentData.contentId == null &&
                            download.request.uri.toString() == contentData.url!!
                        ) {
                            DownloadManagerUtil.getInstance()
                                .addDownload(contentData, download)
                        }
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            print(e.message)
        }
    }

    fun getFirstFormatWithDrmInitData(
        onSuccess: ((Format) -> Unit)?,
        onFailed: ((WvException) -> Unit)?
    ) {
//        if (downloadHelper == null || contentData.url == null) {
//            onFailed?.invoke(
//                WvException.ContentDataException(null, "downloadHelper or contentData is null")
//            )
//            return
//        }
        val helper = downloadHelper ?: run {
            onFailed?.invoke(
                WvException.ContentDataException(null, "downloader object is null")
            )
            return
        }

        val url = contentData.url ?: run {
            onFailed?.invoke(
                WvException.ContentDataException(null, "content url is null")
            )
            return
        }

        val uri = Uri.parse(url)
        CoroutineScope(Dispatchers.Default).launch {
            val result = when (Util.inferContentType(uri)) {
                C.CONTENT_TYPE_DASH -> processDashContent(helper)
                C.CONTENT_TYPE_HLS -> processHlsContent(uri)
                else -> null
            }

            launch(Dispatchers.Main) {
                result?.let { (format, uuid) ->
                    if (uuid == C.WIDEVINE_UUID) {
                        onSuccess?.invoke(format)
                    } else {
                        handleFailure(uuid, onFailed)
                    }
                } ?: onFailed?.invoke(
                    WvException.DownloadException(null, "not supported type or failed to get DrmInitData")
                )
            }
        }
    }

    private fun processDashContent(helper: DownloadHelper): Pair<Format, UUID?>? {
        for (period in 0 until helper.periodCount) {
            helper.getMappedTrackInfo(period)
                .let { trackInfo ->
                    findSupportedFormat(trackInfo)?.let { return it }
                }
        }
        return null
    }

    private fun findSupportedFormat(trackInfo: MappingTrackSelector.MappedTrackInfo): Pair<Format, UUID?>? {
        for (renderer in 0 until trackInfo.rendererCount) {
            val trackGroups = trackInfo.getTrackGroups(renderer)

            for (groupIndex in 0 until trackGroups.length) {
                val group = trackGroups[groupIndex]

                for (formatIndex in 0 until group.length) {
                    val format = group.getFormat(formatIndex)
                    val classification = classifyFormat(format)

                    if (classification != SKIP_FORMAT) {
                        return format to classification
                    }
                }
            }
        }
        return null
    }

    private fun classifyFormat(format: Format): UUID? {
        val uuid = getDrmUuid(format)

        return when {
            format.cryptoType == C.CRYPTO_TYPE_NONE && uuid == null -> {
                // Non-DRM content - null UUID indicates no DRM
                null
            }
            uuid == C.CLEARKEY_UUID -> {
                // Clear Key DRM content
                uuid
            }
            uuid == C.WIDEVINE_UUID -> {
                // Widevine DRM content
                uuid
            }
            else -> {
                // Unsupported DRM or other format - skip
                SKIP_FORMAT
            }
        }
    }

    companion object {
        private val SKIP_FORMAT = UUID(0, 0) // Sentinel value for skipping
    }

//    private fun processDashContent(): Pair<Format, UUID?>? {
//        for (periodIndex in 0 until downloadHelper!!.periodCount) {
//            val mappedTrackInfo = downloadHelper!!.getMappedTrackInfo(periodIndex)
//            for (rendererIndex in 0 until mappedTrackInfo.rendererCount) {
//                val trackGroups = mappedTrackInfo.getTrackGroups(rendererIndex)
//                for (trackGroupIndex in 0 until trackGroups.length) {
//                    val trackGroup = trackGroups[trackGroupIndex]
//                    for (formatIndex in 0 until trackGroup.length) {
//                        val format = trackGroup.getFormat(formatIndex)
//                        val uuid = getDrmUuid(format)
//                        when {
//                            format.cryptoType == C.CRYPTO_TYPE_NONE && uuid == null -> {
//                                // Non-DRM content
//                                return format to null
//                            }
//                            uuid == C.CLEARKEY_UUID -> {
//                                // Clear Key DRM content
//                                return format to uuid
//                            }
//                            uuid == C.WIDEVINE_UUID -> {
//                                // Widevine DRM content
//                                return format to uuid
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return null
//    }

    private fun processHlsContent(uri: Uri): Pair<Format, UUID?>? {
        val format = getFormatFromHlsUri(null, uri) ?: return null
        val uuid = getDrmUuid(format)
        when {
            format.cryptoType == C.CRYPTO_TYPE_NONE && uuid == null -> {
                // Non-DRM content
                return format to null
            }
            uuid == C.CLEARKEY_UUID -> {
                // Clear Key DRM content
                return format to uuid
            }
            uuid == C.WIDEVINE_UUID -> {
                // Widevine DRM content
                return format to uuid
            }
        }
        return null
    }

    private fun getDrmUuid(format: Format): UUID? {
        return format.drmInitData?.run {
            for (i in 0 until schemeDataCount) {
                val uuid = get(i).uuid
                if (uuid == C.WIDEVINE_UUID || uuid == C.CLEARKEY_UUID) return uuid
            }
            null
        }
    }

    private fun handleFailure(uuid: UUID?, onFailed: ((WvException) -> Unit)?) {
        when (uuid) {
            null -> onFailed?.invoke(WvException.ClearKeyLicenseException(null, "Non DRM"))
            C.CLEARKEY_UUID -> onFailed?.invoke(WvException.ClearKeyLicenseException(null, "Clear Key Content"))
            else -> onFailed?.invoke(WvException.DownloadException(null, "failed get DrmInitData"))
        }
    }

    private fun getFormatFromHlsUri(format: Format?, uri: Uri): Format? {
        val inputStream = getInputStreamFromUri(uri)
        val playList =
            HlsPlaylistParser().parse(uri, inputStream)

        when (playList) {
            is HlsMultivariantPlaylist -> {
                for (variant in playList.variants) {
                    if (variant.format.drmInitData != null) {
                        return variant.format
                    } else {
                        return getFormatFromHlsUri(variant.format, variant.url)
                    }
                }
            }

            is HlsMediaPlaylist -> {
                if (format == null) {
//                    throw IllegalArgumentException("Format must not be null")
                    return null
                }

                for (segment in playList.segments) {
                    if (segment.drmInitData != null) {
                        return Format.Builder()
                            .setId(format.id)
                            .setLabel(format.label)
                            .setContainerMimeType(format.containerMimeType)
                            .setSelectionFlags(format.selectionFlags)
                            .setRoleFlags(format.roleFlags)
                            .setLanguage(format.language)
                            .setDrmInitData(segment.drmInitData)
                            .build()
                    }
                }
            }

            else -> return null
        }

        return format
    }


    fun getInputStreamFromUri(uri: Uri): InputStream {
        val remoteUrl = URL(uri.toString())
        val urlConnection = remoteUrl.openConnection() as HttpURLConnection
        urlConnection.requestMethod = "GET"
        if (urlConnection.responseCode == HttpURLConnection.HTTP_OK) {
            return urlConnection.inputStream
        } else {
            throw WvException.NetworkConnectedException(null, "code : ${urlConnection.responseCode}, message : ${urlConnection.responseMessage}")
        }
    }

    fun getTracks(): DownloaderTracks? {
        if (downloadHelper == null)
            return null

        val tracks = DownloaderTracks()
        for (periodIndex in 0 until downloadHelper!!.periodCount) {
            val mappedTrackInfo = downloadHelper!!.getMappedTrackInfo(periodIndex)
            for (rendererIndex in 0 until mappedTrackInfo.rendererCount) {
                val trackGroups = mappedTrackInfo.getTrackGroups(rendererIndex)
                for (trackGroupIndex in 0 until trackGroups.length) {
                    val trackGroup = trackGroups[trackGroupIndex]
                    for (formatIndex in 0 until trackGroup.length) {
                        val format = trackGroup.getFormat(formatIndex)
                        val renderType = mappedTrackInfo.getRendererType(rendererIndex)
                        if (renderType == 1) { // Audio
                            val trackInfo = AudioTrackInfo(format)
                            if (tracks.audio.size == 0) {
                                trackInfo.isDownload = true
                            }
                            tracks.audio.add(trackInfo)
                        } else if (renderType == 2) { // Video
                            val trackInfo = VideoTrackInfo(format)
                            if (tracks.video.size == 0) {
                                trackInfo.isDownload = true
                            }
                            tracks.video.add(trackInfo)
                        } else if (renderType == 3) { // Subtitle
                            val trackInfo = TextTrackInfo(format)
                            if (tracks.text.size == 0) {
                                trackInfo.isDownload = true
                            }
                            tracks.text.add(trackInfo)
                        }
                    }
                }
            }
        }
        return tracks
    }

    private fun buildTrackSelectionParameters(
        context: Context,
        helper: DownloadHelper,
        tracks: DownloaderTracks
    ): TrackSelectionParameters {
        val overrides = mutableListOf<TrackSelectionOverride>()

        // 선택된 포맷들을 미리 Set으로 만들어 둠 (null 체크 추가)
        val selectedVideoFormats = tracks.video
            .filter { it.isDownload }
            .mapNotNull { it.format }
            .toSet()
        val selectedAudioFormats = tracks.audio
            .filter { it.isDownload }
            .mapNotNull { it.format }
            .toSet()
        val selectedTextFormats = tracks.text
            .filter { it.isDownload }
            .mapNotNull { it.format }
            .toSet()

        try {
            for (periodIndex in 0 until helper.periodCount) {
                val mapped = helper.getMappedTrackInfo(periodIndex)
                for (rendererIndex in 0 until mapped.rendererCount) {
                    val type = mapped.getRendererType(rendererIndex)
                    val groups = mapped.getTrackGroups(rendererIndex)

                    for (groupIndex in 0 until groups.length) {
                        val tg = groups[groupIndex]
                        val pickedIndices = mutableListOf<Int>()

                        for (trackIndex in 0 until tg.length) {
                            val f = tg.getFormat(trackIndex)
                            when (type) {
                                C.TRACK_TYPE_VIDEO -> if (f in selectedVideoFormats) pickedIndices += trackIndex
                                C.TRACK_TYPE_AUDIO -> if (f in selectedAudioFormats) pickedIndices += trackIndex
                                C.TRACK_TYPE_TEXT  -> if (f in selectedTextFormats)  pickedIndices += trackIndex
                            }
                        }

                        if (pickedIndices.isNotEmpty()) {
                            overrides += TrackSelectionOverride(tg, pickedIndices)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            throw WvException.DownloadException(e, "Failed to build track selection parameters: ${e.message}")
        }

        return buildParamsWithOverrides(overrides)
    }

    private fun buildParamsWithOverrides(
        overrides: List<TrackSelectionOverride>
    ): TrackSelectionParameters {
        val builder = TrackSelectionParameters.Builder()
        overrides.forEach { override ->
            builder.addOverride(override)
        }
        return builder.build()
    }

//    private fun setHelperForTracks(helper: DownloadHelper, tracks: DownloaderTracks) {
//        if (downloadHelper == null) {
//            throw WvException.DownloadException(null, "downloader object is null")
//        }
//
//        // 모든 기간에 대해 트랙 선택을 초기화합니다.
//        for (periodIndex in 0 until downloadHelper!!.periodCount) {
//            downloadHelper!!.clearTrackSelections(periodIndex)
//        }
//
//        // DefaultTrackSelector.Parameters.DEFAULT를 사용하여 빌더를 시작합니다.
//        val parametersBuilder = DefaultTrackSelector.Parameters.DEFAULT
//            .buildUpon() // 기존 파라미터를 기반으로 빌더 생성
//
//        // 비디오 트랙 선택
//        val selectedVideoIndices = tracks.video.withIndex()
//            .filter { it.value.isDownload }
//            .map { it.index }
//            .toIntArray()
//
//        if (selectedVideoIndices.isNotEmpty()) {
//            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false) // 비디오 렌더러 활성화
//            parametersBuilder.setOverrideForType(
//                DefaultTrackSelector.SelectionOverride(
//                    C.TRACK_TYPE_VIDEO, // 렌더러 타입
//                    0, // TrackGroup 인덱스 (대부분 0이지만 여러 개일 수 있음)
//                    *selectedVideoIndices // 선택할 트랙 인덱스들
//                )
//            )
//        } else {
//            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true) // 비디오 렌더러 비활성화
//        }
//
//
//        // 오디오 트랙 선택
//        val selectedAudioTrackIndices = tracks.audio.withIndex()
//            .filter { it.value.isDownload }
//            .map { it.index }
//            .toIntArray()
//
//        if (selectedAudioTrackIndices.isNotEmpty()) {
//            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false) // 오디오 렌더러 활성화
//            parametersBuilder.setOverrideForType(
//                DefaultTrackSelector.SelectionOverride(
//                    C.TRACK_TYPE_AUDIO, // 렌더러 타입
//                    0, // TrackGroup 인덱스
//                    *selectedAudioTrackIndices // 선택할 트랙 인덱스들
//                )
//            )
//        } else {
//            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true) // 오디오 렌더러 비활성화
//        }
//
//        // 텍스트 트랙 선택 (자막)
//        val selectedTextTrackIndices = tracks.text.withIndex()
//            .filter { it.value.isDownload }
//            .map { it.index }
//            .toIntArray()
//
//        if (selectedTextTrackIndices.isNotEmpty()) {
//            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false) // 텍스트 렌더러 활성화
//            parametersBuilder.setOverrideForType(
//                DefaultTrackSelector.SelectionOverride(
//                    C.TRACK_TYPE_TEXT, // 렌더러 타입
//                    0, // TrackGroup 인덱스
//                    *selectedTextTrackIndices // 선택할 트랙 인덱스들
//                )
//            )
//        } else {
//            parametersBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true) // 텍스트 렌더러 비활성화
//        }
//
//        // 최종적으로 TrackSelectionParameters를 빌드하고 DownloadHelper에 적용합니다.
//        downloadHelper!!.addTrackSelection(0, parametersBuilder.build())
//    }

//    private fun setHelperForTracks(helper: DownloadHelper, tracks: DownloaderTracks) {
//        for (periodIndex in 0 until downloadHelper!!.periodCount) {
//            helper.clearTrackSelections(periodIndex)
//        }
//        val videoList = ArrayList<DefaultTrackSelector.SelectionOverride>()
//        val audioList = ArrayList<DefaultTrackSelector.SelectionOverride>()
//        val textList = ArrayList<DefaultTrackSelector.SelectionOverride>()
//        if (tracks.video.any { it.isDownload }) {
//            val selectedVideoIndices = tracks.video.withIndex()
//                .filter { it.value.isDownload }
//                .map { it.index }
//                .toIntArray()
//
//            if (selectedVideoIndices.isNotEmpty()) {
//                val videoSelection =
//                    DefaultTrackSelector.SelectionOverride(0, *selectedVideoIndices)
//                videoList.add(videoSelection)
//            }
//        }
//
//
//        for (i in 0 until tracks.audio.size) {
//            if (tracks.audio.get(i).isDownload) {
//                val selection = DefaultTrackSelector.SelectionOverride(i, 0)
//                audioList.add(selection)
//            }
//        }
//
//        for (i in 0 until tracks.text.size) {
//            if (tracks.text.get(i).isDownload) {
//                val selection = DefaultTrackSelector.SelectionOverride(i, 0)
//                textList.add(selection)
//            }
//        }
//
//        if (videoList.size > 0) {
//            helper.addTrackSelectionForSingleRenderer(
//                0,
//                0,
//                DownloadHelper.DEFAULT_TRACK_SELECTOR_PARAMETERS,
//                videoList
//            )
//        }
//
//        if (audioList.size > 0) {
//            helper.addTrackSelectionForSingleRenderer(
//                0,
//                1,
//                DownloadHelper.DEFAULT_TRACK_SELECTOR_PARAMETERS,
//                audioList
//            )
//        }
//
//        if (textList.size > 0) {
//            helper.addTrackSelectionForSingleRenderer(
//                0,
//                2,
//                DownloadHelper.DEFAULT_TRACK_SELECTOR_PARAMETERS,
//                textList
//            )
//        }
//    }

    private fun processListener(download: Download) {
        if (DownloadManagerUtil.getInstance()
                .getDownload(contentData) == null) {
            throw WvException.DownloadException(null, "failed processListener about download object is null")
        }

//        val pallyConEventListener = GlobalObjectUtil.getInstance().pallyConEventListener
        if (download.state == Download.STATE_DOWNLOADING) {
            if (job == null) {
                job = CoroutineScope(Dispatchers.Default).launch {
//                    val downloadObject = download ?: return@launch // null 체크
                    var preBytesDownloaded = download.bytesDownloaded

                    while (download.state == Download.STATE_DOWNLOADING) {
                        if (preBytesDownloaded < download.bytesDownloaded) {
                            withContext(Dispatchers.Main) {
                                if (download.state == Download.STATE_DOWNLOADING) {
                                    GlobalObjectUtil.getInstance().notifyProgress(
                                        contentData,
                                        download.percentDownloaded,
                                        download.bytesDownloaded
                                    )
                                }
                            }
                            preBytesDownloaded = download.bytesDownloaded
                        }
                        delay(500)
                    }
                }
            }
        } else {
            if (job != null) {
                job!!.cancel()
                job = null
            }

            CoroutineScope(Dispatchers.Main).launch {
                DownloadManagerUtil.getInstance()
                    .getDownload(contentData)?.let { obj ->
                    val state = obj.state
                    when (state) {
                        Download.STATE_COMPLETED ->
                            GlobalObjectUtil.getInstance().notifyCompleted(contentData)
                        Download.STATE_FAILED ->
                            GlobalObjectUtil.getInstance().notifyFailed(
                                contentData,
                                WvException.DownloadException(null, "Download failed")
                            )
                        Download.STATE_RESTARTING ->
                            GlobalObjectUtil.getInstance().notifyRestarting(contentData)
                        Download.STATE_STOPPED ->
                            GlobalObjectUtil.getInstance().notifyStopped(contentData)
                        Download.STATE_REMOVING ->
                            GlobalObjectUtil.getInstance().notifyRemoved(contentData)
                    }
                }
            }
        }
    }

    fun getDownloadFileInformation(): FileInformation {
        if (contentData.url == null || DownloadManagerUtil.getInstance()
                .getDownload(contentData) == null) {
            return FileInformation(
                0,
                null,
                null,
            )
        }

        val util = DownloadManagerUtil.getInstance()

        val migratedContent = if (contentData.contentId != null) {
            DBManager.getInstance(context).getOldContentLocalUrl(contentData.contentId!!)
        } else {
            ""
        }

        if (migratedContent.isNotEmpty()) {
            val directoryPath = migratedContent.substring(0, migratedContent.lastIndexOf('/'));
            val directory = File(directoryPath)
            val downloadedFileSize =
                directory.walkTopDown().filter { it.isFile }.map { it.length() }.sum()

            return FileInformation(
                downloadedFileSize,
                null,
                directory,
            )
        } else {
            return FileInformation(
                DownloadManagerUtil.getInstance()
                    .getDownload(contentData)!!.bytesDownloaded,
                util.getCache(context),
                util.getDirectory(context),
            )
        }
    }
}