package com.doverunner.widevine.exception

sealed class WvException(val e: Exception?, val msg: String): RuntimeException(msg) {
    class DetectedDeviceTimeModifiedException(e: Exception?, msg: String) : WvException(e, msg)

    class NetworkConnectedException(e: Exception?, msg: String) : WvException(e, msg)

    class DownloadException(e: Exception?, msg: String) : WvException(e, msg)

    class DrmException(e: Exception?, msg: String) : WvException(e, msg)

    class ContentDataException(e: Exception?, msg: String) : WvException(e, msg)

    class MigrationException(e: Exception?, msg: String) : WvException(e, msg)

    class MigrationLocalPathException(e: Exception?, msg: String) : WvException(e, msg)

    class WvLicenseCipherException(e: Exception?, msg: String): WvException(e, msg)

    class ClearKeyLicenseException(e: Exception?, msg: String) : WvException(e, msg)
}