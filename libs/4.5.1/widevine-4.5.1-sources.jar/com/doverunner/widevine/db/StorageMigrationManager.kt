package com.doverunner.widevine.db

import android.content.Context

class StorageMigrationManager(private val context: Context) {

    suspend fun shouldMigrate(): Boolean {
        return try {
            val legacyStorage = LegacySecureStorage(context)
            legacyStorage.getAllEntries().isNotEmpty()
        } catch (e: Exception) {
            false
        }
    }

    suspend fun performMigration(
        from: LegacySecureStorage,
        to: KeystoreSecureStorage
    ) {
        val legacyData = from.getAllEntries()

        legacyData.forEach { (key, value) ->
            when (value) {
                is Long -> to.putLong(key, value)
                is String -> to.putString(key, value)
                else -> to.putString(key, value.toString())
            }
        }

        // 마이그레이션 완료 마킹
        to.putString("migration_completed", "true")

        // Legacy 데이터 삭제
        from.clear()
    }
}