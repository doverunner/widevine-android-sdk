package com.doverunner.widevine.db

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.GeneralSecurityException
import javax.crypto.AEADBadTagException

class LegacySecureStorage(private val context: Context) : SecureStorage {
    @Suppress("DEPRECATION")
    private val preferences: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "pallycon_setting",
        getMasterKey(context),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    @Suppress("DEPRECATION")
    private fun getMasterKey(context: Context): MasterKey {
        return MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    override suspend fun putString(key: String, value: String) {
        preferences.edit().putString(key, value).apply()
    }

    override suspend fun getString(key: String): String? {
        return try {
            preferences.getString(key, null)
        } catch (e: AEADBadTagException) {
            Log.e("LegacySecureStorage", "AEAD decryption failed for key: $key", e)
            null
        } catch (e: GeneralSecurityException) {
            Log.e("LegacySecureStorage", "Security exception for key: $key", e)
            null
        } catch (e: Exception) {
            Log.e("LegacySecureStorage", "Unexpected error reading key: $key", e)
            null
        }
    }

    override suspend fun putLong(key: String, value: Long) {
        preferences.edit().putLong(key, value).apply()
    }

    override suspend fun getLong(key: String): Long {
        return try {
            preferences.getLong(key, 0L)
        } catch (e: AEADBadTagException) {
            Log.e("LegacySecureStorage", "AEAD decryption failed for key: $key", e)
            0L
        } catch (e: GeneralSecurityException) {
            Log.e("LegacySecureStorage", "Security exception for key: $key", e)
            0L
        } catch (e: Exception) {
            Log.e("LegacySecureStorage", "Unexpected error reading key: $key", e)
            0L
        }
    }

    override suspend fun remove(key: String) {
        preferences.edit().remove(key).apply()
    }

    override suspend fun clear() {
        preferences.edit().clear().apply()
    }

    override suspend fun getAllStringEntries(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        try {
            preferences.all.forEach { (key, value) ->
                if (value is String && !isSystemKey(key)) {
                    try {
                        result[key] = value
                    } catch (e: AEADBadTagException) {
                        Log.e("LegacySecureStorage", "AEAD decryption failed for key: $key", e)
                    } catch (e: GeneralSecurityException) {
                        Log.e("LegacySecureStorage", "Security exception for key: $key", e)
                    } catch (e: Exception) {
                        Log.e("LegacySecureStorage", "Unexpected error reading key: $key", e)
                    }
                }
            }
        } catch (e: AEADBadTagException) {
            Log.e("LegacySecureStorage", "AEAD decryption failed while reading all entries", e)
        } catch (e: GeneralSecurityException) {
            Log.e("LegacySecureStorage", "Security exception while reading all entries", e)
        } catch (e: Exception) {
            Log.e("LegacySecureStorage", "Unexpected error reading all entries", e)
        }
        return result
    }

    private fun isSystemKey(keyName: String): Boolean {
        return keyName in listOf("secure_tick_time", "secure_tick_count")
    }

    fun getAllEntries(): Map<String, *> {
        return try {
            preferences.all
        } catch (e: AEADBadTagException) {
            Log.e("LegacySecureStorage", "AEAD decryption failed while reading all entries", e)
            emptyMap<String, Any?>()
        } catch (e: GeneralSecurityException) {
            Log.e("LegacySecureStorage", "Security exception while reading all entries", e)
            emptyMap<String, Any?>()
        } catch (e: Exception) {
            Log.e("LegacySecureStorage", "Unexpected error reading all entries", e)
            emptyMap<String, Any?>()
        }
    }
}