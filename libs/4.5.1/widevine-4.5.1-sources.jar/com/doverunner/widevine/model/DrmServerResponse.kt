package com.doverunner.widevine.model

import com.doverunner.widevine.drm.WvLicenseServerError

sealed class DrmServerResponse {
    data class Error(val error: WvLicenseServerError) : DrmServerResponse()
    data class License(val license: LicenseResponse) : DrmServerResponse()
    data class RawData(val data: ByteArray) : DrmServerResponse()
}