package com.doverunner.widevine.model

import com.google.gson.annotations.SerializedName

data class DeviceInfo(
    @field:SerializedName("device_id") val deviceId: String,
    @field:SerializedName("device_model") val deviceModel: String,
    @field:SerializedName("os_version") val osVersion: String,
    @field:SerializedName("session_id") val sessionId: String,
    @field:SerializedName("is_chrome_cdm") val isChromeCdm: Boolean
)