package com.doverunner.widevine.migration

import android.content.Context
import android.database.sqlite.SQLiteException
import com.doverunner.widevine.db.DBManager
import com.doverunner.widevine.downloader.DownloadManager
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.util.DownloadManagerUtil
import java.io.File

class SDKMigration {
    companion object {
        fun needsMigrateContent(
            context: Context,
            cid: String,
            siteId: String,
        ): Boolean {
            val db = DatabaseManager(context)
            val DBManager = DBManager.getInstance(context)
            return db.getContent(cid, siteId) != null &&
                    DBManager.getOldContentLocalUrl(cid).isEmpty()
        }

        fun removeOldContentDB(
            context: Context,
            cid: String,
            siteId: String
        ): Boolean {
            return try {
                val db = DatabaseManager(context)
                db.deleteContent(cid, siteId)
            } catch (e: SQLiteException) {
                false
            }
        }

        fun migrateDB(
            context: Context,
            url: String,
            cid: String,
            siteId: String,
            contentName: String,
            downloadedFolderName: String? = null,
            downloadManager: DownloadManager
        ): Boolean {
            val db = DatabaseManager(context)
            val DBManager = DBManager.getInstance(context)
            db.getContent(cid, siteId)?.let { recordContent ->
                val startTimeMs = System.currentTimeMillis() - (24 * 60 * 60 * 1000)

                val directory = context.getExternalFilesDir(null) ?:
                    throw WvException.MigrationException(null, "" +
                            "getExternalFilesDir exception")

                val userDirectory = DownloadManagerUtil.getInstance().getDirectory(context)

                if (directory.absolutePath.contains(userDirectory.absolutePath, ignoreCase = true)) {
                    throw WvException.MigrationLocalPathException(null, "" +
                            "The download directory location must be different from the existing download location.")
                }

                try {
                    if (url.contains(directory.absolutePath) &&
                            contentName.isEmpty() &&
                            downloadedFolderName == null) {
                        DBManager.setOldContentLocalUrl(cid, url)
                    } else {
                        val fromDirectory = if (downloadedFolderName == null) {
                            directory.absolutePath + "/" + contentName
                        } else {
                            directory.absolutePath + "/" + downloadedFolderName + "/" + contentName
                        }

                        val from = File(fromDirectory)
                        val fileName = url.substring( url.lastIndexOf("/") + 1)
                        DBManager.setOldContentLocalUrl(cid, from.absolutePath + "/" + fileName)
                    }

                    println("Directory moved successfully.")
                } catch (e: Exception) {
                    throw WvException.MigrationException(e, "" +
                            "failed move the content")
                }

                downloadManager.setLicenseForMigration(
                    url, cid,
                    recordContent.getKeySetId(),
                    startTimeMs
                )

                val allKey = downloadManager.getAllDownloadKeySetIds()
                if (allKey.find { keySetId ->
                        keySetId.size == recordContent.getKeySetId().size &&
                                recordContent.getKeySetId().filter { !keySetId.contains(it)
                                }.isEmpty() } != null)
                    return true
            }

            return false
        }
    }

}