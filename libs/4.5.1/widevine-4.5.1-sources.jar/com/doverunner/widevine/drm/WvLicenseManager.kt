package com.doverunner.widevine.drm

import android.content.Context
import android.os.Handler
import android.util.Pair
import androidx.media3.common.Format
import androidx.media3.common.util.Util
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.DrmSession
import androidx.media3.exoplayer.drm.DrmSessionEventListener
import androidx.media3.exoplayer.drm.DrmSessionManager
import androidx.media3.exoplayer.drm.DummyExoMediaDrm
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.OfflineLicenseHelper
import androidx.media3.exoplayer.drm.UnsupportedDrmException
import androidx.media3.exoplayer.source.MediaSource
import com.doverunner.widevine.cmcd.CmcdManager
import com.doverunner.widevine.exception.WvException
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.model.DrmInformation
import com.doverunner.widevine.util.DeviceInfo
import com.doverunner.widevine.util.GlobalObjectUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** @suppress */
class WvLicenseManager(
    private val context: Context,
    private val contentData: ContentData,
    factory: OkHttpDataSource.Factory,
) {
    private var offlineLicenseHelper: OfflineLicenseHelper
    private var drmSessionManager: DrmSessionManager
    private var wvMediaDrmCallback: WvMediaDrmCallback = WvMediaDrmCallback(context, factory)
    private var drmEventDispatcher = DrmSessionEventListener.EventDispatcher()
    private var handler: Handler? = null// = Util.createHandlerForCurrentLooper()
    private var isUsedDrmSessionManager = false

    init {
        val deviceInfo = DeviceInfo.getDeviceInfo()
        contentData.drmConfig?.let {
            wvMediaDrmCallback.setDrmServerRequestHeader(
                contentData,
                deviceInfo
            )
        }

        wvMediaDrmCallback.addEventLicenseServerException {
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, it)
            }
        }

        wvMediaDrmCallback.addEventWvException {
            CoroutineScope(Dispatchers.Main).launch {
                GlobalObjectUtil.getInstance().notifyFailed(contentData, it)
            }
        }

        drmSessionManager = createDrmSessionManager()

        offlineLicenseHelper = OfflineLicenseHelper(
            createDrmSessionManager(),
            drmEventDispatcher
        )

        try {
            handler = Util.createHandlerForCurrentLooper()
        } catch (e: IllegalStateException) {
            print(e.message)
        }

        if (handler == null) {
            handler = Util.createHandlerForCurrentOrMainLooper()
        }

        drmEventDispatcher.addEventListener(handler!!, object: DrmSessionEventListener {
            override fun onDrmKeysLoaded(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmKeysLoaded(windowIndex, mediaPeriodId)
                print("onDrmKeysLoaded")
            }

            override fun onDrmKeysRemoved(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmKeysRemoved(windowIndex, mediaPeriodId)
                print("onDrmKeysRemoved")
            }

            override fun onDrmKeysRestored(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmKeysRestored(windowIndex, mediaPeriodId)
                print("onDrmKeysRestored")
            }

            override fun onDrmSessionAcquired(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
                state: Int,
            ) {
                super.onDrmSessionAcquired(windowIndex, mediaPeriodId, state)
                print("onDrmSessionAcquired")
            }

            override fun onDrmSessionManagerError(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
                error: java.lang.Exception,
            ) {
                super.onDrmSessionManagerError(windowIndex, mediaPeriodId, error)
                print("onDrmSessionManagerError")
//                pallyConEventListener?.onFailed(contentData.url,
//                    PallyConException.DrmException("DRM error. ${error.message}"))
            }

            override fun onDrmSessionReleased(
                windowIndex: Int,
                mediaPeriodId: MediaSource.MediaPeriodId?,
            ) {
                super.onDrmSessionReleased(windowIndex, mediaPeriodId)
                print("onDrmSessionReleased")
            }
        })
    }

    fun createDrmSessionManager(): DefaultDrmSessionManager {
        return DefaultDrmSessionManager.Builder()
            .setUuidAndExoMediaDrmProvider(
                contentData.drmConfig!!.uuid
            ) { uuid ->
                try {
                    // Force L3.
//                    mediaDrm.setPropertyString("securityLevel", "L3")
                    return@setUuidAndExoMediaDrmProvider FrameworkMediaDrm.newInstance(uuid)
                } catch (e: UnsupportedDrmException) {
                    return@setUuidAndExoMediaDrmProvider DummyExoMediaDrm()
                }
            }
            .setMultiSession(true)
            .build(wvMediaDrmCallback)
    }

    fun getDrmSession(): DrmSessionManager {
        if (isUsedDrmSessionManager) {
            reCreateDrmSession()
        }
        isUsedDrmSessionManager = true
        return drmSessionManager
    }

    fun reCreateDrmSession() {
//        CoroutineScope(Dispatchers.IO).launch {
//            drmSessionManager?.release()
//        }
//        drmSessionManager?.release()
        drmSessionManager = createDrmSessionManager()
    }

    fun downloadLicense(
        format: Format,
        onSuccess: ((ByteArray) -> Unit)?,
        onFailed: ((WvException.DrmException) -> Unit)?,
    ) {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val licenseData = offlineLicenseHelper.downloadLicense(format)
                onSuccess?.invoke(licenseData)
            } catch (e: DrmSession.DrmSessionException) {
                onFailed?.invoke(WvException.DrmException(e, "DrmSession Exception : " + e.message))
            } catch (e: java.lang.NullPointerException) {
                onFailed?.invoke(WvException.DrmException(e, "Download License Exception"))
            } catch (e: java.lang.Exception) {
                onFailed?.invoke(WvException.DrmException(e, "Download License Exception"))
            } finally {
                CmcdManager.getInstance().flushOnce()
            }
        }
    }

    fun getDrmInformation(keySetId: ByteArray): DrmInformation {
        try {
            val licenseDurationRemainingSec: Pair<Long, Long> =
                offlineLicenseHelper.getLicenseDurationRemainingSec(keySetId)

            return DrmInformation(
                licenseDurationRemainingSec.first,
                licenseDurationRemainingSec.second
            )
        } catch (e: DrmSession.DrmSessionException) {
            throw WvException.DrmException(e, "Problem with DRM : ${e.message}")
        } catch (e: Exception) {
            throw WvException.DrmException(e, "Problem with DRM : ${e.message}")
        }
    }

    fun renewDrmLicense(keySetId: ByteArray): ByteArray {
        try {
            return offlineLicenseHelper.renewLicense(keySetId)
        } catch (e: DrmSession.DrmSessionException) {
            throw WvException.DrmException(e, "failed renew drm license : ${e.message}")
        } catch (e: Exception) {
            throw WvException.DrmException(e, "failed renew drm license : ${e.message}")
        }
    }

    fun removeDrmLicense(keySetId: ByteArray) {
        try {
            offlineLicenseHelper.releaseLicense(keySetId)
        } catch (e: DrmSession.DrmSessionException) {
            // 6004 means that the error is caused by a feature that is not currently supported by the server.
            if (e.errorCode != 6004) {
                throw WvException.DrmException(e, "failed renew drm license : ${e.message}")
            }
        } catch (e: Exception) {
            throw WvException.DrmException(e, "failed renew drm license : ${e.message}")
        }
    }
}