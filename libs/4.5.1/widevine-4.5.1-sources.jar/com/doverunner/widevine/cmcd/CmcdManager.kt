package com.doverunner.widevine.cmcd

import android.content.Context
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CmcdManager {

    private var cmcdSdk: Any? = null
    private val endPoint = "http://192.168.0.220:5555"

    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    companion object {
        private var instance: CmcdManager? = null

        fun getInstance(): CmcdManager {
            return instance ?: synchronized(this) {
                instance ?: CmcdManager().also { obj ->
                    instance = obj
                }
            }
        }
    }

    fun createObject(
        context: Context
    ) {
//        if (cmcdSdk != null) return

        val bearer: String? = null
        val apiKey = "YOUR-API-KEY"

        cmcdSdk = CmcdReflectionCaller.callCmcdSdkFactoryCreate(context, endPoint, bearer, apiKey)
    }

    fun attach(player: Player) {
        cmcdSdk?.let {
            CmcdReflectionCaller.callAttachReflected(it, player)
        }
    }

    fun setContentId(cid: String) {
        cmcdSdk?.let {
            CmcdReflectionCaller.callSetContentIdReflected(it, cid)
        }
    }

    fun setAuthData(authData: String) {
        cmcdSdk?.let {
            CmcdReflectionCaller.callSetAuthDataReflected(it, authData)
        }
    }

    fun setVersion(version: String) {
        cmcdSdk?.let {
            CmcdReflectionCaller.callSetVersionReflected(it, version)
        }
    }

    fun record(eventKey: String? = null, msgType: String? = null,
               drmErrorCode: String? = null, responseCode: String? = null) {
        cmcdSdk?.let {
            val specificEvent = SdkEvent(
                ts = System.currentTimeMillis(), // 필수: 현재 타임스탬프
                event = "t",                     // 필수: 이벤트 타입 (예: "e"는 오류)
                eventKey = eventKey,
                msgType = msgType,
                drmErrorCode = responseCode,
                serverResponseCode = drmErrorCode,
                custom = mapOf()
            )

            coroutineScope.launch {
                CmcdReflectionCaller.callRecordReflected(it, specificEvent)
            }
        }
    }

    fun flushOnce() {
        cmcdSdk?.let {
            coroutineScope.launch {
                CmcdReflectionCaller.callFlushOnceReflected(it)
            }
        }
    }
}