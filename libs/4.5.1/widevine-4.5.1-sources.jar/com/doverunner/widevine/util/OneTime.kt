package com.doverunner.widevine.util

import android.content.Context
import android.util.Log
import com.doverunner.widevine.BuildConfig

class OneTime private constructor() {
    companion object {
        private var instance: OneTime? = null

        private lateinit var context: Context

        private const val TAG = "DoveRunnerWvSDKLog"

        fun getInstance(_context: Context): OneTime {
            return instance ?: synchronized(this) {
                instance ?: OneTime().also {
                    context = _context
                    instance = it
                    Log.e(TAG, "-------------------------------------")
                    Log.e(TAG, "-- DoveRunner WideVine SDK version : " + BuildConfig.VERSION_NAME)
                    Log.e(TAG, "-------------------------------------")
                }
            }
        }
    }
}