package com.doverunner.widevine.util

import android.content.Context
import androidx.media3.database.DatabaseProvider
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.cache.Cache
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import com.doverunner.widevine.model.ContentData
import com.doverunner.widevine.service.DrmDownloadService
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.Executors

/** @suppress */
class DownloadManagerUtil {
    private var downloadManager: DownloadManager? = null
    private var databaseProvider: DatabaseProvider? = null
    private var cache: Cache? = null
    private var httpDataSource: HttpDataSource.Factory? = null
    private var downloadNotificationHelper: DownloadNotificationHelper? = null
    private var downloadDirectory: String? = null
    private var directory: File? = null
    private var notificationChannelId = "download_channel"
    private val listeners = mutableMapOf<String, DownloadListener>()
    val downloads = mutableMapOf<String, Download>()
    private var isStartDownloadService = false
//    private var downloadManager: DownloadManager? = null
//    private val caches = mutableMapOf<File, Cache>()
//    private var currentContentData: ContentData? = null
    var downloadService: Class<out DownloadService?> = DrmDownloadService::class.java

    interface DownloadListener {
        /** Called when the tracked downloads changed.  */
        fun onDownloadsChanged(
            download: Download,
            finalException: Exception?,
        )

        fun onDownloadRemoved(download: Download)
    }

    companion object {
        private var instance: DownloadManagerUtil? = null

        fun getInstance(): DownloadManagerUtil {
            return instance ?: synchronized(this) {
                instance ?: DownloadManagerUtil().also {
                    instance = it
                }
            }
        }

        fun release() {
            instance = null
        }
    }

    fun release() {
        downloadManager?.release()
        cache?.release()

        downloadManager = null
        cache = null
//        downloadManagers.forEach {
//            it.value.release()
//        }
//        downloadManagers.clear()
//        caches.forEach {
//            it.value.release()
//        }
//        caches.clear()
    }

    fun getDirectory(context: Context): File {
        return directory ?: synchronized(this) {
            directory ?: createDirectory(context).also {
                directory = it
            }
        }

//        if (this.directory == null || directory!!.length() < 1) {
//            val fi = context.getExternalFilesDir(null) ?: context.filesDir
//            this.directory = File(fi, "downloads");
//        }
//        return this.directory!!

//        if (contentData?.localPath != null) {
//            this.directory = File(contentData.localPath!!)
//        } else {
//            val fi = context.getExternalFilesDir(null) ?: context.filesDir
//            this.directory = File(fi, "downloads")
//        }
//
//        return this.directory!!
    }

    fun createDirectory(context: Context): File {
        return if (this.downloadDirectory != null) {
            File(this.downloadDirectory!!)
        } else {
            val fi = context.getExternalFilesDir(null) ?: context.filesDir
            File(fi, "downloads")
        }
    }

    fun setService(service: Class<out DownloadService?>?) {
        downloadService = service ?: DrmDownloadService::class.java
    }

    fun startDownloadService(context: Context) {
        if (!isStartDownloadService) {
            try {
                DownloadService.start(context, downloadService)
            } catch (e: IllegalStateException) {
                DownloadService.startForeground(context, downloadService)
            }
//            PallyConDownloadService.startService(context, downloadService, contentData)
            isStartDownloadService = true
        }

//        PallyConDownloadService.startService(context, downloadService, contentData)
//        if (!isStartDownloadService) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                DownloadService.startForeground(context, downloadService)
//            } else {
//                DownloadService.start(context, downloadService)
//            }
//            isStartDownloadService = true
//        }
    }

    fun setNotificationChannelId(id: String) {
        this.notificationChannelId = id
    }

    fun getNotificationChannelId(): String {
        return this.notificationChannelId
    }

    fun getDatabaseProvider(context: Context): DatabaseProvider {
        return databaseProvider ?: synchronized(this) {
            databaseProvider ?: StandaloneDatabaseProvider(context).also {
                databaseProvider = it
            }
        }
//        return StandaloneDatabaseProvider(context)
    }

    fun getCache(context: Context): Cache {
        return cache ?: synchronized(this) {
            cache ?: run{
                var dir = getDirectory(context)
                SimpleCache(dir,
                    NoOpCacheEvictor(),
                    getDatabaseProvider(context)
                ).also {
                    cache = it
                }
            }
        }
    }

    fun getHttpDataSource(): HttpDataSource.Factory {
        return httpDataSource ?: synchronized(this) {
            httpDataSource ?: OkHttpDataSource.Factory(
                OkHttpClient.Builder()
//                    .addInterceptor(CustomInterceptor())
                    .build()
            ).also {
                httpDataSource = it
            }
        }

    }

    fun getDownloadManager(context: Context): DownloadManager {
        return downloadManager ?: synchronized(this) {
            downloadManager ?: createDownloadManager(context).also {
                downloadManager = it
            }
        }
    }

    fun setDownloadDirectory(context: Context, directoryName: String) {
        downloadDirectory = directoryName
        release()
        this.downloadManager = createDownloadManager(context)
    }

    fun createDownloadManager(context: Context): DownloadManager {
        return DownloadManager(
            context,
            getDatabaseProvider(context),
            getCache(context),
            getHttpDataSource(),
            Executors.newFixedThreadPool(6)
        ).also {
            it.addListener(object : DownloadManager.Listener {
                override fun onDownloadChanged(
                    downloadManager: DownloadManager,
                    download: Download,
                    finalException: Exception?,
                ) {
                    super.onDownloadChanged(downloadManager, download, finalException)
                    listeners[download.request.id]?.onDownloadsChanged(download, finalException)
                }

                override fun onDownloadRemoved(downloadManager: DownloadManager, download: Download) {
                    super.onDownloadRemoved(downloadManager, download)
                    listeners[download.request.id]?.onDownloadRemoved(download)
                }
            })
        }
    }

    fun getDownloadNotificationHelper(context: Context): DownloadNotificationHelper {
        return downloadNotificationHelper ?: synchronized(this) {
            downloadNotificationHelper ?: DownloadNotificationHelper(
                context,
                this.notificationChannelId
            ).also {
                downloadNotificationHelper = it
            }
        }
    }

    fun addDownloadManagerListener(contentId: String?, contentUrl: String, listener: DownloadListener) {
        if (contentId != null) {
            listeners[contentId] = listener
        } else {
            listeners[contentUrl] = listener
        }
    }

    fun removeDownloadManagerListener(contentId: String?, contentUrl: String) {
        if (contentId != null) {
            listeners.remove(contentId)
        } else {
            listeners.remove(contentUrl)
        }
    }

    fun addDownload(contentData: ContentData, download: Download) {
        if (contentData.contentId != null) {
            downloads[contentData.contentId!!] = download
        } else {
            downloads[contentData.url!!] = download
        }
    }

    fun getDownload(contentData: ContentData): Download? {
        return if (contentData.contentId != null) {
            downloads[contentData.contentId!!]
        } else {
            downloads[contentData.url!!]
        }
    }
}

